
drop table FATCA_IND;
