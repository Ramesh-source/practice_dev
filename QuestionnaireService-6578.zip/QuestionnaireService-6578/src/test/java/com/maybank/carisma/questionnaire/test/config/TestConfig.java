package com.maybank.carisma.questionnaire.test.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


@ComponentScan(basePackages = {"com.maybank.mdm.customer.controller",
		"com.maybank.mdm.customer.service",
		"com.maybank.mdm.customer.util",
		"com.maybank.mdm.customer.common",
		"com.maybank.mdm.customer.dao",
		"com.maybank.mdm.customer.entity",
		"com.maybank.mdm.customer.specifications"})
public class TestConfig  implements WebMvcConfigurer{

 }

