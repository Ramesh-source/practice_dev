package com.maybank.carisma.questionnaire.test.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@PropertySource("db_test.properties")
@EnableJpaRepositories(basePackages = {"com.maybank.mdm.customer.dao","com.maybank.carisma.dao.commonQuestionnaire"})
@ComponentScan(basePackages = {"com.maybank.carisma","com.maybank.mdm.customer.controller",
		"com.maybank.mdm.customer.service",
		"com.maybank.mdm.customer.util",
		"com.maybank.mdm.customer.common",
		"com.maybank.mdm.customer.dao",
		"com.maybank.mdm.customer.entity",
		"com.maybank.mdm.entity",
		"com.maybank.mdm.dao",
		"com.maybank.mdm.constants",
		"com.maybank.mdm.listeners",
		"com.maybank.mdm.service",
		"com.maybank.mdm.controller.extensibleData",
		"com.maybank.mdm.service.metadata",
		"com.maybank.mdm.vo.metadata",
		"com.maybank.mdm.vo.extensibleData",
		"com.maybank.mdm.customer.criteria",
		"com.maybank.mdm.customer.criteria.impl",
		"com.maybank.mdm.customer.specifications",
		"com.maybank.mdm.vo.events",
		"com.maybank.bprm.dto",
		"com.maybank.common.utils",
		"com.maybank.mdm.common.cache",
		"com.maybank.mdm.common.utils",
		"com.maybank.carisma.dao.commonQuestionnaire",
		"com.maybank.carisma.questionnaire",
		"com.maybank.carisma.entity.questionnaire",
		"com.maybank.common.service.config",
		"com.maybank.bprm.integration",
		"com.maybank.mdm.customer.service.bprm","com.maybank.common.service.wscall","com.maybank.mdm.vo.extensibleData"})


@ActiveProfiles("dev")
public class JpaTestConfig {

	@Autowired
	private Environment env;

	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory(){

		LocalContainerEntityManagerFactoryBean lcemfb
		= new LocalContainerEntityManagerFactoryBean();

		lcemfb.setDataSource(this.dataSource());
		lcemfb.setPackagesToScan(new String[] {"com.maybank.carisma","com.maybank.mdm.customer.controller",
				"com.maybank.mdm.customer.service",
				"com.maybank.mdm.customer.util",
				"com.maybank.mdm.customer.common",
				"com.maybank.mdm.customer.dao",
				"com.maybank.mdm.customer.entity",
				"com.maybank.mdm.entity",
				"com.maybank.mdm.dao",
				"com.maybank.mdm.constants",
				"com.maybank.mdm.listeners",
				"com.maybank.mdm.service",
				"com.maybank.mdm.vo.metadata",
				"com.maybank.mdm.controller.extensibleData",
				"com.maybank.mdm.service.extensibleData",
				"com.maybank.mdm.customer.criteria",
				"com.maybank.mdm.customer.criteria.impl",
				"com.maybank.mdm.customer.specifications",
				"com.maybank.mdm.vo.events",
				"com.maybank.common.service.config",
				"com.maybank.carisma.dao.commonQuestionnaire",
				"com.maybank.carisma.questionnaire",
				"com.maybank.carisma.entity.questionnaire",
				"com.maybank.common.utils",
				"com.maybank.bprm.integration",
				"com.maybank.mdm.customer.service.bprm",
				"com.maybank.common.service.wscall",
				"com.maybank.mdm.vo.extensibleData"});

		HibernateJpaVendorAdapter va = new HibernateJpaVendorAdapter();
		lcemfb.setJpaVendorAdapter(va);

		Properties ps = new Properties();
		ps.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		ps.put("hibernate.hbm2ddl.auto", "create");
		ps.put("hibernate.show_sql", "true");
		lcemfb.setJpaProperties(ps);

		lcemfb.afterPropertiesSet();

		return lcemfb;

	}

	@Bean
	public DataSource dataSource(){

		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getProperty("jdbc.driverClassName"));
		dataSource.setUrl(env.getProperty("jdbc.url"));
		dataSource.setUsername(env.getProperty("jdbc.user"));
		dataSource.setPassword(env.getProperty("jdbc.pass"));

		return dataSource;

	}

	@Bean
	public PlatformTransactionManager transactionManager(){

		JpaTransactionManager tm = new JpaTransactionManager();

		tm.setEntityManagerFactory(
				this.entityManagerFactory().getObject() );

		return tm;

	}

	@Bean
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation(){
		return new PersistenceExceptionTranslationPostProcessor();
	}


	@Bean
	public JdbcTemplate jdbcTemplate() {
		return new JdbcTemplate(dataSource());
	}

}
