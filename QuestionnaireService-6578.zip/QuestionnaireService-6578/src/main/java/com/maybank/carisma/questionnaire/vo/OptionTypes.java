package com.maybank.carisma.questionnaire.vo;

public enum OptionTypes {

	S("select"),

	R("radio"),

	C("checkbox"),

	I("fieldgroup"),

	W("switch"),

	L("linear radio"),

	D("double select"),

	B("button"),

	T("date"),
	
	K("currency"),
	
	H("header"),
	
	V("select"),
	
	E("fieldgroupmultiline"),
	
	X("fieldgroupcalculated");
	
	private String action;

	public String getAction() {
		return this.action;
	}

	private OptionTypes(String action) {
		this.action = action;
	}

}
