package com.maybank.carisma.questionnaire.enhancement.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.maybank.carisma.questionnaire.constant.QuestionnaireConstant;
import com.maybank.carisma.questionnaire.enhancement.enumeration.dao.EnhancedQuestionnaireServiceDAO;
import com.maybank.carisma.questionnaire.entity.AvlOptionsToQuestion;
import com.maybank.carisma.questionnaire.entity.QuestionMaster;
import com.maybank.carisma.questionnaire.entity.Questionnaire;
import com.maybank.carisma.questionnaire.entity.QuestionnaireSections;
import com.maybank.carisma.questionnaire.service.QuestionnaireService;
import com.maybank.carisma.questionnaire.vo.ComponentMetadataDTO;
import com.maybank.carisma.questionnaire.vo.ExtendedValues;
import com.maybank.carisma.questionnaire.vo.OptionDTO;
import com.maybank.carisma.questionnaire.vo.OptionTypes;
import com.maybank.carisma.questionnaire.vo.QuestionDTO;
import com.maybank.carisma.questionnaire.vo.QuestionResponse;
import com.maybank.carisma.questionnaire.vo.SectionDetails;
import com.maybank.carisma.questionnaire.vo.SubSectionDetails;
import com.maybank.carisma.questionnaire.vo.TypeOfDisplay;
import com.maybank.carisma.questionnaire.vo.QuestionMasterValidationBean;
import com.maybank.carisma.util.common.CollectionUtil;

@Component("enhancedQuestionnaireServiceHelper")
public class EnhancedQuestionnaireServiceHelper {

	@Autowired
	EnhancedQuestionnaireServiceDAO enhancedQuestionnaireServiceDAO;
	
	@Autowired
	SeededList seededList;

	private String convertQuestionType(String questionType) {
		System.out.println("EQSHelper: questionType: " + questionType);
		
		String cQuestionType = null;
		switch (questionType) {
		case "M":
			cQuestionType = OptionTypes.S.getAction();
			break;
		case "S":
			cQuestionType = OptionTypes.S.getAction();
			break;
		case "R":
			cQuestionType = OptionTypes.R.getAction();
			break;
		case "C":
			cQuestionType = OptionTypes.C.getAction();
			break;
		case "I":
			cQuestionType = OptionTypes.I.getAction();

			break;
		case "W":
			cQuestionType = OptionTypes.W.getAction();

			break;
		case "L":
			cQuestionType = OptionTypes.L.getAction();

			break;
		case "D":
			cQuestionType = OptionTypes.D.getAction();

			break;
		case "B":
			cQuestionType = OptionTypes.B.getAction();

			break;
		case "T":
			cQuestionType = OptionTypes.T.getAction();

			break;
		case "K":
			cQuestionType = OptionTypes.K.getAction();
			
			break;
		case "H":
			cQuestionType = OptionTypes.H.getAction();
			break;
		case "E":
			cQuestionType = OptionTypes.E.getAction();
			break;		
		case "X":
			cQuestionType = OptionTypes.X.getAction();
			break;				
		default:
			cQuestionType = OptionTypes.S.getAction();

			break;
		}
		return cQuestionType;
	}

	public void constructQuestionnaireResponse(Questionnaire questionnaire, QuestionResponse questionResponse,
			Locale locale) {

		if(questionnaire.getIsStatic() != null) {
			if(questionnaire.getIsStatic().equals("Y")) {
				questionResponse.setQuestionnaireProperty(QuestionnaireConstant.STATIC);
			}
			else if(questionnaire.getIsStatic().equals("N")) {
				questionResponse.setQuestionnaireProperty(QuestionnaireConstant.DYNAMIC);
			} 
		}
		
		if(questionnaire.getTypeOfDisplay() != null) {
			if(questionnaire.getTypeOfDisplay().equals(QuestionnaireConstant.DISPLAY_TYPE_HS)) {
				questionResponse.setTypeOfDisplay(TypeOfDisplay.HIDE_SHOW);
			}
			else if(questionnaire.getTypeOfDisplay().equals(QuestionnaireConstant.DISPLAY_TYPE_ED)) {
				questionResponse.setTypeOfDisplay(TypeOfDisplay.ENABLE_DISABLE);
			} 
		}
	}

	public void constructQuestionnaireSections(List<QuestionnaireSections> questionnaireSectionList, QuestionResponse questionResponse, Locale locale) {

		if (questionnaireSectionList != null && questionnaireSectionList.size() > 0) {
			List<SectionDetails> sectionDetailsList = new ArrayList<SectionDetails>();
			
			for (QuestionnaireSections questionnaireSection : questionnaireSectionList) {
				SectionDetails sectionDetail = new SectionDetails();
				sectionDetail.setSectionName((String) QuestionnaireService.infoMap.get(questionnaireSection.getSectionCode()).get(locale));
				sectionDetail.setSectionId(questionnaireSection.getnQuestionnaireSectionsId());
				sectionDetail.setSectionOrder(questionnaireSection.getSectionOrder());
				
				List<SubSectionDetails> subSectionDetailList = new ArrayList<SubSectionDetails>();
				List<QuestionMaster> questionMasters = enhancedQuestionnaireServiceDAO.getQuestionMastersForSectionId(questionnaireSection.getnQuestionnaireSectionsId()); // 8

				if (questionMasters != null && questionMasters.size() > 0) {
					subSectionDetailList.add(constructQuestionMaster(questionMasters, locale));					
				}
				sectionDetail.setSubSectionDetails(subSectionDetailList);
				sectionDetail.setMultipleResponses(Boolean.valueOf(questionnaireSection.getfMulpitpleSections()));
				if (questionnaireSection.getSectionHref() != null) {
					sectionDetail.setSectionHref((String) QuestionnaireService.infoMap.get(questionnaireSection.getSectionHref()).get(locale));
				}
				sectionDetailsList.add(sectionDetail);
			}
			Comparator<SectionDetails> compareBySectionOrder = (SectionDetails o1, SectionDetails o2) -> o1
					.getSectionOrder().compareTo(o2.getSectionOrder());
			Collections.sort(sectionDetailsList, compareBySectionOrder);

			questionResponse.setSectionDetails(sectionDetailsList);
		}
	}

	public SubSectionDetails constructQuestionMaster(List<QuestionMaster> questionMasters, Locale locale) {

		SubSectionDetails subSectionDetails = new SubSectionDetails();
		List<QuestionDTO> componentDetails = new ArrayList<QuestionDTO>();
		if (questionMasters != null && questionMasters.size() > 0) {
			questionMasters.forEach(questionMaster -> {

				if (!QuestionnaireService.questionRemarkMap.containsValue(questionMaster.getNQuestionMasterId())) {
					System.out.println("Next QuestionMaster: " + questionMaster.toString());
					QuestionDTO questionDTO = new QuestionDTO();
					questionDTO.setQuestionId(questionMaster.getNQuestionMasterId());
					questionDTO.setQuestion(questionMaster.getVQuestion());
					questionDTO.setOptionType(questionMaster.getVOptionSelectionType());
					questionDTO.setQuestionType(convertQuestionType(questionMaster.getVOptionSelectionType()));
					questionDTO.setFormName(questionMaster.getFormName());
	
					try {
						questionDTO.setQuestionDesc((String) QuestionnaireService.infoMap.get(questionMaster.getVQuestion()).get(locale));
					} catch (Exception e) {
						System.err.println("Message Not Found: " + questionMaster.getVQuestion());
						questionDTO.setQuestionDesc("Dummy-Message");
					}
					
					if (questionMaster.getQuestionTooltip() != null) {
						questionDTO.setQuestionTooltip((String) QuestionnaireService.infoMap.get(questionMaster.getQuestionTooltip()).get(locale));
					}
					
					if (questionMaster.getQuestionHref() != null) {
						questionDTO.setQuestionHref((String) QuestionnaireService.infoMap.get(questionMaster.getQuestionHref()).get(locale));
					}					
					
					// questionDTO.setGenericUIFieldValidationList(new ArrayList<ValidationVo>());
					
					if (!CollectionUtil.isEmpty(QuestionnaireService.mapValidationsByQuestionnaireId.get(questionDTO.getQuestionId()))) {
						questionDTO.setGenericUIFieldValidationList(QuestionnaireService.mapValidationsByQuestionnaireId.get(questionDTO.getQuestionId()));
						for (QuestionMasterValidationBean validVo : questionDTO.getGenericUIFieldValidationList()) {
							if (QuestionnaireService.infoMap != null) {
								validVo.setErrorMsg(((String) QuestionnaireService.infoMap.get(validVo.getErrorCode()).get(locale)));
							}
							if("REGEX".equals(validVo.getValidationType()) && (null != validVo.getValidationValue() && !"".equals(validVo.getValidationValue())) ) {
								validVo.setRegex(enhancedQuestionnaireServiceDAO.getRegexValue(validVo.getValidationValue()));
							}
						}
					} else {
						questionDTO.setGenericUIFieldValidationList(new ArrayList<QuestionMasterValidationBean>()); // empty-list
					}
	
					questionDTO.setIsDisplayNone(Boolean.valueOf(questionMaster.getIsDisplayNone()));
					questionDTO.setExtendedAttrVo(new ArrayList<ExtendedValues>());
					questionDTO.setQuestionOrder(questionMaster.getQuestionOrder());
					questionDTO.setRule(questionMaster.getRule());
					questionDTO.setRuleParams(questionMaster.getRuleParams());
					
					/* calling a helper function to set component metadata inside questionDTO */				
					addComponentMetadata(questionDTO);
					
					if (QuestionnaireService.questionRemarkMap.containsKey(questionMaster.getNQuestionMasterId())) {
						questionDTO.setHasRemark(true);
						
						Long remarkId = QuestionnaireService.questionRemarkMap.get(questionMaster.getNQuestionMasterId());
						if (!CollectionUtil.isEmpty(QuestionnaireService.mapValidationsByQuestionnaireId.get(remarkId))) {
							List<QuestionMasterValidationBean> validationVoList = QuestionnaireService.mapValidationsByQuestionnaireId.get(remarkId);
							QuestionMasterValidationBean validationVo = validationVoList.get(0);
							if (validationVo.getRemarkMandatoryValidation() != null) {
								questionDTO.setRemarkMandatoryFor(validationVo.getRemarkMandatoryValidation());
							}
							else {
								questionDTO.setRemarkMandatoryFor("");
							}
						}
					}
					
					List<AvlOptionsToQuestion> avlOptionsToQuestionList = enhancedQuestionnaireServiceDAO
							.getAvlOptionsToQuestionForQuestionId(questionMaster.getNQuestionMasterId());
					constructAvlOptionsToQuestions(avlOptionsToQuestionList, questionDTO, locale);
					componentDetails.add(questionDTO);
				}
			});

			Comparator<QuestionDTO> compareByQuesterOrder = (QuestionDTO o1, QuestionDTO o2) -> o1.getQuestionOrder()
					.compareTo(o2.getQuestionOrder());			
			Collections.sort(componentDetails, compareByQuesterOrder);
			subSectionDetails.setComponentDetails(componentDetails);
		}
		return subSectionDetails;

	}
	
	private void addComponentMetadata(QuestionDTO questionDTO) {
		if (!CollectionUtil.isEmpty(QuestionnaireService.componentMetadataMap.get(questionDTO.getQuestionId()))) {
			questionDTO.setComponentMetadataList(QuestionnaireService.componentMetadataMap.get(questionDTO.getQuestionId()));
		} else {
			List<ComponentMetadataDTO> dto = new ArrayList<>();
			questionDTO.setComponentMetadataList(dto);
		}
	}

	public void constructAvlOptionsToQuestions(List<AvlOptionsToQuestion> avlOptionsToQuestionList,
			QuestionDTO questionDTO, Locale locale) {
		String optionType,optVal="V";
		optionType = questionDTO.getOptionType();
		
		if (!optionType.equals(optVal))
		{
			if (avlOptionsToQuestionList != null && avlOptionsToQuestionList.size() > 0) {
				avlOptionsToQuestionList.forEach(avlOptionsToQuestions -> {
					OptionDTO optionDTO = new OptionDTO();
					
					optionDTO.setOptionId(avlOptionsToQuestions.getNAvlOptionsToQuestionsId());
					optionDTO.setOption(avlOptionsToQuestions.getVOption());
					optionDTO.setOptionDesc((String) QuestionnaireService.infoMap.get(avlOptionsToQuestions.getVOption()).get(locale));
					optionDTO.setIsLeaf(Boolean.valueOf(avlOptionsToQuestions.getFIsLeaf()));
					optionDTO.setIsSelected(false);
					optionDTO.setOptionOrder(avlOptionsToQuestions.getnOptionOrder());

					questionDTO.getOptionMap().add(optionDTO);
				});
			}
		}
		else {
			String tName="",cName="";
			Long optionId=null;
			Boolean isLeaf=false;
			if (avlOptionsToQuestionList != null && avlOptionsToQuestionList.size() > 0) {
				for(AvlOptionsToQuestion avlOptionsToQuestions:avlOptionsToQuestionList) {
					OptionDTO optionDTO = new OptionDTO();
					
					optionDTO.setOptionId(avlOptionsToQuestions.getNAvlOptionsToQuestionsId());
					
					optionDTO.setOption(avlOptionsToQuestions.getVOption());
					optionDTO.setOptionDesc((String) QuestionnaireService.infoMap.get(avlOptionsToQuestions.getVOption()).get(locale));
					optionDTO.setIsLeaf(Boolean.valueOf(avlOptionsToQuestions.getFIsLeaf()));
					optionDTO.setIsSelected(false);
					optionDTO.setOptionOrder(avlOptionsToQuestions.getnOptionOrder());

					if (avlOptionsToQuestions.getVOption().equals("UCO_LV_TABLE")) {
						tName = optionDTO.getOptionDesc();
						optionId = optionDTO.getOptionId();
						isLeaf = optionDTO.getIsLeaf();
					}
					else
						cName = optionDTO.getOptionDesc();
					
				}};

				List<String> sList = seededList.getSeededList(tName, cName);
				for (int i = 0; i < sList.size(); i++) {
					 
					optionId = optionId + 1;
					OptionDTO optionDTO = new OptionDTO();
					optionDTO.setOptionId(optionId);
					optionDTO.setOption("UCO_"+sList.get(i));
					optionDTO.setOptionDesc(sList.get(i));
					optionDTO.setIsLeaf(isLeaf);
					optionDTO.setIsSelected(false);
					optionDTO.setOptionOrder(i+1);
		            questionDTO.getOptionMap().add(optionDTO);
		        }
			}
		}
}
