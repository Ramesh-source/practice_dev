package com.maybank.carisma.questionnaire.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * The Class QuestionnaireDTO.
 * 
 *  @author Sangit Banik
 */
public class QuestionnaireDTO implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2361023974485906413L;
	
	/** The questionnaire list. */
	private List<QuestionDTO> questionnaireList;
	
	/**
	 * Instantiates a new questionnaire DTO.
	 */
	public QuestionnaireDTO() {
		questionnaireList = new ArrayList<>();
    }

	/**
	 * Gets the questionnaire list.
	 *
	 * @return the questionnaire list
	 */
	public List<QuestionDTO> getQuestionnaireList() {
		return questionnaireList;
	}

	/**
	 * Sets the questionnaire list.
	 *
	 * @param questionnaireList the new questionnaire list
	 */
	public void setQuestionnaireList(List<QuestionDTO> questionnaireList) {
		this.questionnaireList = questionnaireList;
	}	
	
}
