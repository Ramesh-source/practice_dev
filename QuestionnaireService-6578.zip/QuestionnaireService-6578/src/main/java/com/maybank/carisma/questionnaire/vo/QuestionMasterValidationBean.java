package com.maybank.carisma.questionnaire.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class QuestionMasterValidationBean {

	private long questionValidationId;

	@JsonIgnore
	private long questionnaireId;

	@JsonIgnore
	private long questionMasterId;

	private String validationType;

	private String validationValue;

	@JsonIgnore
	private String errorCode;

	private String remarkMandatoryValidation;

	private String errorMsg;

	private String regex;

	public long getQuestionValidationId() {
		return questionValidationId;
	}

	public QuestionMasterValidationBean setQuestionValidationId(long questionValidationId) {
		this.questionValidationId = questionValidationId;
		return this;
	}

	public long getQuestionnaireId() {
		return questionnaireId;
	}

	public QuestionMasterValidationBean setQuestionnaireId(long questionnaireId) {
		this.questionnaireId = questionnaireId;
		return this;
	}

	public long getQuestionMasterId() {
		return questionMasterId;
	}

	public QuestionMasterValidationBean setQuestionMasterId(long questionMasterId) {
		this.questionMasterId = questionMasterId;
		return this;
	}

	public String getValidationType() {
		return validationType;
	}

	public QuestionMasterValidationBean setValidationType(String validationType) {
		this.validationType = validationType;
		return this;
	}

	public String getValidationValue() {
		return validationValue;
	}

	public QuestionMasterValidationBean setValidationValue(String validationValue) {
		this.validationValue = validationValue;
		return this;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public QuestionMasterValidationBean setErrorCode(String errorCode) {
		this.errorCode = errorCode;
		return this;
	}

	public String getRemarkMandatoryValidation() {
		return remarkMandatoryValidation;
	}

	public QuestionMasterValidationBean setRemarkMandatoryValidation(String remarkMandatoryValidation) {
		this.remarkMandatoryValidation = remarkMandatoryValidation;
		return this;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public QuestionMasterValidationBean setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
		return this;
	}

	public String getRegex() {
		return regex;
	}

	public QuestionMasterValidationBean setRegex(String regex) {
		this.regex = regex;
		return this;
	}

}
