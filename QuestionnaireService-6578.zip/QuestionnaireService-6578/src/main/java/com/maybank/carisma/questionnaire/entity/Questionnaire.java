package com.maybank.carisma.questionnaire.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the QUESTIONNAIRE database table.
 * 
 */
@Entity
@Table(name = "Questionnaire")
@NamedQueries({ @NamedQuery(name = Questionnaire.findAll1, query = "SELECT q FROM Questionnaire q"),
		@NamedQuery(name = Questionnaire.GET_QUESTIONNAIRE, query = "SELECT q FROM Questionnaire q WHERE q.nQuestionnaireId = :questionnaireId"),
		@NamedQuery(name=Questionnaire.GET_ALL_ENTITY_TYPES, query="SELECT q.vQuestionnaireName FROM Questionnaire q WHERE q.isStatic=:isStatic"),})
public class Questionnaire implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -803049520092464530L;

	public static final String findAll1 = "findAll";

	public static final String GET_ALL_ENTITY_TYPES = "GET_ALL_ENTITY_TYPES";

	public static final String GET_QUESTIONNAIRE = "GET_QUESTIONNAIRE";

	/** The n questionnaire id. */
	@Id
	@SequenceGenerator(name = "questionnaire", sequenceName = "SEQ_QUESTIONNAIRE_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "questionnaire")
	@Column(name = "N_QUESTIONNAIRE_ID")
	private long nQuestionnaireId;

	/** The v questionnaire name. */
	@Column(name = "V_QUESTIONNAIRE_NAME")
	private String vQuestionnaireName;

	@Column(name = "F_IS_STATIC")
	private String isStatic;

	@Column(name = "V_TYPE_OF_DISPLAY")
	private String typeOfDisplay;

	@Column(name = "V_RESPONSE_TABLE_NAME")
	private String responseTableName;

	@Column(name = "V_RESPONSE_STYLE")
	private String responseStyle;

	@Column(name = "F_SEPARATE_RESPONSE_SECTION")
	private String separateTableFlag;

	public String getResponseTableName() {
		return responseTableName;
	}

	public void setResponseTableName(String responseTableName) {
		this.responseTableName = responseTableName;
	}

	/** The questionnaire question maps. */
	// bi-directional many-to-one association to QuestionnaireQuestionMap
	@OneToMany(mappedBy = "questionnaire")
	private Set<QuestionnaireQuestionMap> questionnaireQuestionMaps;

	@OneToMany(mappedBy = "questionnaire")
	private Set<QuestionnaireSections> questionnaireSections;

	public Set<QuestionnaireSections> getQuestionnaireSections() {
		return questionnaireSections;
	}

	public void setQuestionnaireSections(Set<QuestionnaireSections> questionnaireSections) {
		this.questionnaireSections = questionnaireSections;
	}

	/**
	 * Gets the n questionnaire id.
	 *
	 * @return the n questionnaire id
	 */
	public long getNQuestionnaireId() {
		return this.nQuestionnaireId;
	}

	/**
	 * Sets the n questionnaire id.
	 *
	 * @param nQuestionnaireId the new n questionnaire id
	 */
	public void setNQuestionnaireId(long nQuestionnaireId) {
		this.nQuestionnaireId = nQuestionnaireId;
	}

	/**
	 * Gets the v questionnaire name.
	 *
	 * @return the v questionnaire name
	 */
	public String getVQuestionnaireName() {
		return this.vQuestionnaireName;
	}

	/**
	 * Sets the v questionnaire name.
	 *
	 * @param vQuestionnaireName the new v questionnaire name
	 */
	public void setVQuestionnaireName(String vQuestionnaireName) {
		this.vQuestionnaireName = vQuestionnaireName;
	}

	/**
	 * Gets the questionnaire question maps.
	 *
	 * @return the questionnaire question maps
	 */
	public Set<QuestionnaireQuestionMap> getQuestionnaireQuestionMaps() {
		return this.questionnaireQuestionMaps;
	}

	/**
	 * Sets the questionnaire question maps.
	 *
	 * @param questionnaireQuestionMaps the new questionnaire question maps
	 */
	public void setQuestionnaireQuestionMaps(Set<QuestionnaireQuestionMap> questionnaireQuestionMaps) {
		this.questionnaireQuestionMaps = questionnaireQuestionMaps;
	}

	/**
	 * Adds the questionnaire question map.
	 *
	 * @param questionnaireQuestionMap the questionnaire question map
	 * @return the questionnaire question map
	 */
	public QuestionnaireQuestionMap addQuestionnaireQuestionMap(QuestionnaireQuestionMap questionnaireQuestionMap) {
		getQuestionnaireQuestionMaps().add(questionnaireQuestionMap);
		questionnaireQuestionMap.setQuestionnaire(this);

		return questionnaireQuestionMap;
	}

	/**
	 * Removes the questionnaire question map.
	 *
	 * @param questionnaireQuestionMap the questionnaire question map
	 * @return the questionnaire question map
	 */
	public QuestionnaireQuestionMap removeQuestionnaireQuestionMap(QuestionnaireQuestionMap questionnaireQuestionMap) {
		getQuestionnaireQuestionMaps().remove(questionnaireQuestionMap);
		questionnaireQuestionMap.setQuestionnaire(null);

		return questionnaireQuestionMap;
	}

	// enhancement

	public String getIsStatic() {
		return isStatic;
	}

	public void setIsStatic(String isStatic) {
		this.isStatic = isStatic;
	}

	public String getTypeOfDisplay() {
		return typeOfDisplay;
	}

	public void setTypeOfDisplay(String typeOfDisplay) {
		this.typeOfDisplay = typeOfDisplay;
	}

	//

	@Column(name = "V_MODULE_NAME")
	private String moduleName;

	/**
	 * @return the moduleName
	 */
	public String getModuleName() {
		return moduleName;
	}

	/**
	 * @param moduleName the moduleName to set
	 */
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

}