package com.maybank.carisma.questionnaire.vo;

import java.io.Serializable;
import java.util.List;
import java.util.Set;
import java.util.LinkedHashSet;
import java.util.TreeSet;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The Class QuestionDTO.
 * 
 * @author Sangit Banik
 */
public class QuestionDTO implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1035718041158866907L;

	/** The question id. */
	private Long questionId;

	/** The question. */
	private String question;

	/** The option type. */
	private String optionType;

	/** The question type. */
	private String questionType;

	/** The form name. */
	private String formName;

	/** The question desc. */
	private String questionDesc;

	/** The generic UI field validation list. */
	private List<QuestionMasterValidationBean> genericUIFieldValidationList;

	/** The option map. */
	private LinkedHashSet<OptionDTO> optionMap;

	/** The is static. */
	@JsonIgnore
	private String isStatic;

	/** The is display none. */
	private Boolean isDisplayNone;

	/** The extended attr vo. */
	private List<ExtendedValues> extendedAttrVo;

	/** The section name. */
	@JsonIgnore
	private String sectionName;

	/** The section id. */
	@JsonIgnore
	private long sectionId;

	/** The type of display. */
	@JsonIgnore
	private TypeOfDisplay typeOfDisplay;

	/** The input answer. */
	@JsonIgnore
	private String inputAnswer;

	/** The section order. */
	@JsonIgnore
	private long sectionOrder;

	/** The multiple responses. */
	@JsonIgnore
	private boolean multipleResponses = false;
	
//	private Character isMandatory;
//
//	/**
//	 * @return the isMandatory
//	 */
//	public Character getIsMandatory() {
//		return isMandatory;
//	}
//
//	/**
//	 * @param isMandatory the isMandatory to set
//	 */
//	public void setIsMandatory(Character isMandatory) {
//		this.isMandatory = isMandatory;
//	}
	
	/** The question tooltip */
	private String questionTooltip;
	
	/** The question Href */
	private String questionHref;	
	
	/** The component metadata list */
	private List<ComponentMetadataDTO> componentMetadataList;
	
	/** Remarks */
	private Boolean hasRemark;

	/**
	 * @return the hasRemark
	 */
	public Boolean getHasRemark() {
		return hasRemark;
	}

	/**
	 * @param hasRemark the hasRemark to set
	 */
	public void setHasRemark(Boolean hasRemark) {
		this.hasRemark = hasRemark;
	}
	
	private String remarkDesc;
	public String getRemarkDesc() {
		return remarkDesc;
	}
	public void setRemarkDesc(String remarkDesc) {
		this.remarkDesc = remarkDesc;
	}
	
	private String remarkMandatoryFor;
	public String getRemarkMandatoryFor() {
		return remarkMandatoryFor;
	}
	public void setRemarkMandatoryFor(String remarkMandatoryFor) {
		this.remarkMandatoryFor = remarkMandatoryFor;
	}

	/**
	 * @return the componentMetadataList
	 */
	public List<ComponentMetadataDTO> getComponentMetadataList() {
		return componentMetadataList;
	}

	/**
	 * @param componentMetadataList the componentMetadataList to set
	 */
	public void setComponentMetadataList(List<ComponentMetadataDTO> componentMetadataList) {
		this.componentMetadataList = componentMetadataList;
	}

	/**
	 * @return the questionTooltip
	 */
	public String getQuestionTooltip() {
		return questionTooltip;
	}

	/**
	 * @param questionTooltip the questionTooltip to set
	 */
	public void setQuestionTooltip(String questionTooltip) {
		this.questionTooltip = questionTooltip;
	}
	
	/**
	 * @return the questionHref
	 */
	public String getQuestionHref() {
		return questionHref;
	}

	/**
	 * @param questionTooltip the questionTooltip to set
	 */
	public void setQuestionHref(String questionHref) {
		this.questionHref = questionHref;
	}	

	/**
	 * Gets the section order.
	 *
	 * @return the section order
	 */
	public long getSectionOrder() {
		return sectionOrder;
	}

	/**
	 * Sets the section order.
	 *
	 * @param sectionOrder the new section order
	 */
	public void setSectionOrder(long sectionOrder) {
		this.sectionOrder = sectionOrder;
	}

	/**
	 * Gets the checks if is display none.
	 *
	 * @return the checks if is display none
	 */
	public Boolean getIsDisplayNone() {
		return isDisplayNone;
	}

	/**
	 * Sets the checks if is display none.
	 *
	 * @param isDisplayNone the new checks if is display none
	 */
	public void setIsDisplayNone(Boolean isDisplayNone) {
		this.isDisplayNone = isDisplayNone;
	}

	/**
	 * Gets the checks if is static.
	 *
	 * @return the checks if is static
	 */
	public String getIsStatic() {
		return isStatic;
	}

	/**
	 * Sets the checks if is static.
	 *
	 * @param isStatic the new checks if is static
	 */
	public void setIsStatic(String isStatic) {
		this.isStatic = isStatic;
	}

	/**
	 * Gets the generic UI field validation list.
	 *
	 * @return the generic UI field validation list
	 */
	public List<QuestionMasterValidationBean> getGenericUIFieldValidationList() {
		return genericUIFieldValidationList;
	}

	/**
	 * Sets the generic UI field validation list.
	 *
	 * @param genericUIFieldValidationList the new generic UI field validation list
	 */
	public void setGenericUIFieldValidationList(List<QuestionMasterValidationBean> genericUIFieldValidationList) {
		this.genericUIFieldValidationList = genericUIFieldValidationList;
	}

	/**
	 * Gets the question desc.
	 *
	 * @return the question desc
	 */
	public String getQuestionDesc() {
		return questionDesc;
	}

	/**
	 * Sets the question desc.
	 *
	 * @param questionDesc the new question desc
	 */
	public void setQuestionDesc(String questionDesc) {
		this.questionDesc = questionDesc;
	}

	/**
	 * Instantiates a new question DTO.
	 */
	public QuestionDTO() {
		optionMap = new LinkedHashSet<OptionDTO>();
	}

	/**
	 * Gets the question id.
	 *
	 * @return the question id
	 */
	public Long getQuestionId() {
		return questionId;
	}

	/**
	 * Sets the question id.
	 *
	 * @param questionId the new question id
	 */
	public void setQuestionId(Long questionId) {
		this.questionId = questionId;
	}

	/**
	 * Gets the question.
	 *
	 * @return the question
	 */
	public String getQuestion() {
		return question;
	}

	/**
	 * Sets the question.
	 *
	 * @param question the new question
	 */
	public void setQuestion(String question) {
		this.question = question;
	}

	/**
	 * Gets the option type.
	 *
	 * @return the option type
	 */
	public String getOptionType() {
		return optionType;
	}

	/**
	 * Sets the option type.
	 *
	 * @param optionType the new option type
	 */
	public void setOptionType(String optionType) {
		this.optionType = optionType;
	}

	/**
	 * Gets the question type.
	 *
	 * @return the question type
	 */
	public String getQuestionType() {
		return questionType;
	}

	/**
	 * Sets the question type.
	 *
	 * @param questionType the new question type
	 */
	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}

	/**
	 * Gets the form name.
	 *
	 * @return the form name
	 */
	public String getFormName() {
		return formName;
	}

	/**
	 * Sets the form name.
	 *
	 * @param formName the new form name
	 */
	public void setFormName(String formName) {
		this.formName = formName;
	}

	/**
	 * Gets the extended attr vo.
	 *
	 * @return the extended attr vo
	 */
	public List<ExtendedValues> getExtendedAttrVo() {
		return extendedAttrVo;
	}

	/**
	 * Sets the extended attr vo.
	 *
	 * @param extendedAttrVo the new extended attr vo
	 */
	public void setExtendedAttrVo(List<ExtendedValues> extendedAttrVo) {
		this.extendedAttrVo = extendedAttrVo;
	}

	/**
	 * Gets the section name.
	 *
	 * @return the section name
	 */
	public String getSectionName() {
		return sectionName;
	}

	/**
	 * Sets the section name.
	 *
	 * @param sectionName the new section name
	 */
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	/**
	 * Gets the section id.
	 *
	 * @return the section id
	 */
	public long getSectionId() {
		return sectionId;
	}

	/**
	 * Sets the section id.
	 *
	 * @param sectionId the new section id
	 */
	public void setSectionId(long sectionId) {
		this.sectionId = sectionId;
	}

	/**
	 * Gets the type of display.
	 *
	 * @return the type of display
	 */
	public TypeOfDisplay getTypeOfDisplay() {
		return typeOfDisplay;
	}

	/**
	 * Sets the type of display.
	 *
	 * @param typeOfDisplay the new type of display
	 */
	public void setTypeOfDisplay(TypeOfDisplay typeOfDisplay) {
		this.typeOfDisplay = typeOfDisplay;
	}

	/**
	 * Gets the input answer.
	 *
	 * @return the input answer
	 */
	public String getInputAnswer() {
		return inputAnswer;
	}

	/**
	 * Sets the input answer.
	 *
	 * @param inputAnswer the new input answer
	 */
	public void setInputAnswer(String inputAnswer) {
		this.inputAnswer = inputAnswer;
	}

	/**
	 * Checks if is multiple responses.
	 *
	 * @return true, if is multiple responses
	 */
	public boolean isMultipleResponses() {
		return multipleResponses;
	}

	/**
	 * Sets the multiple responses.
	 *
	 * @param multipleResponses the new multiple responses
	 */
	public void setMultipleResponses(boolean multipleResponses) {
		this.multipleResponses = multipleResponses;
	}

	// enhancement

	public Set<OptionDTO> getOptionMap() {
		return optionMap;
	}

	public void setOptionMap(LinkedHashSet<OptionDTO> optionMap) {
		this.optionMap = optionMap;
	}

	private Integer questionOrder;

	private String rule;

	private String ruleParams;

	public Integer getQuestionOrder() {
		return questionOrder;
	}

	public void setQuestionOrder(Integer questionOrder) {
		this.questionOrder = questionOrder;
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public String getRuleParams() {
		return ruleParams;
	}

	public void setRuleParams(String ruleParams) {
		this.ruleParams = ruleParams;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "QuestionDTO [questionId=" + questionId + ", question=" + question + ", optionType=" + optionType
				+ ", questionType=" + questionType + ", formName=" + formName + ", questionDesc=" + questionDesc
				+ ", genericUIFieldValidationList=" + genericUIFieldValidationList + ", optionMap=" + optionMap
				+ ", isStatic=" + isStatic + ", isDisplayNone=" + isDisplayNone + ", extendedAttrVo=" + extendedAttrVo
				+ ", sectionName=" + sectionName + ", sectionId=" + sectionId + "]";
	}

}
