package com.maybank.carisma.questionnaire.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.maybank.carisma.dao.commonQuestionnaire.QuestionnaireSaveDao;
import com.maybank.carisma.dao.commonQuestionnaire.QuestionnaireServiceDAO;
import com.maybank.carisma.questionnaire.entity.ComponentMetadata;
import com.maybank.carisma.questionnaire.entity.QuestionMasterValidation;
import com.maybank.carisma.questionnaire.entity.QuestionRemarkMap;
import com.maybank.carisma.questionnaire.vo.ComponentMetadataDTO;
import com.maybank.carisma.questionnaire.vo.ExtendedValues;
import com.maybank.carisma.questionnaire.vo.OptionDTO;
import com.maybank.carisma.questionnaire.vo.OptionTypes;
import com.maybank.carisma.questionnaire.vo.QueriesVo;
import com.maybank.carisma.questionnaire.vo.QuestionAnswerVo;
import com.maybank.carisma.questionnaire.vo.QuestionDTO;
import com.maybank.carisma.questionnaire.vo.QuestionDescVo;
import com.maybank.carisma.questionnaire.vo.QuestionRequest;
import com.maybank.carisma.questionnaire.vo.QuestionResponse;
import com.maybank.carisma.questionnaire.vo.QuestionnaireProperties;
import com.maybank.carisma.questionnaire.vo.SectionDetails;
import com.maybank.carisma.questionnaire.vo.SectionProperties;
import com.maybank.carisma.questionnaire.vo.SortBySortOrder;
import com.maybank.carisma.questionnaire.vo.SubSectionDetails;
import com.maybank.carisma.questionnaire.vo.TypeOfDisplay;
import com.maybank.carisma.questionnaire.vo.QuestionMasterValidationBean;
import com.maybank.carisma.util.common.CollectionUtil;

@Service("questionnaireService")
public class QuestionnaireService {

	private static final Logger logger = LogManager.getLogger(QuestionnaireService.class);

	private static final String DEFAULTLANGUAGE = "defaultLanguage";

	@Autowired
	QuestionnaireSaveService saveService;

	@Autowired
	QuestionnaireServiceDAO questionnaireDAO;

	@Autowired
	QuestionnaireSaveDao saveDao;

	@Autowired
	MessageSource messageSourceVertical;

	public static Map<String, Map<Locale, String>> infoMap;

	public static Map<Long, List<QuestionMasterValidationBean>> mapValidationsByQuestionnaireId;
	
	public static Map<Long, List<ComponentMetadataDTO>> componentMetadataMap;
	
	public static Map<Long, Long> questionRemarkMap;

	private Map<String, QuestionResponse> questionnaireJsonMap;

	private Map<String, QueriesVo> questionQueryMap;

	private Map<String, QuestionnaireProperties> quesProps;

	@PostConstruct
	@Transactional
	public void init() {
		infoMap = getMessageMap();
		mapValidationsByQuestionnaireId = getValdationList();
		componentMetadataMap = getComponentMetadata();
		
		questionRemarkMap = getQuestionRemarkMap();
	}

	private Map<Long, Map<Long, String>> getColumnNamesForQuesId(String entityType) {
		List<Object[]> results = questionnaireDAO.getTableNamesForAllQuesId(entityType);
		Map<Long, Map<Long, String>> secQuestionColMap = new HashMap<>();
		if (!CollectionUtils.isEmpty(results)) {
			results.forEach(result -> {
				if (secQuestionColMap.containsKey((Long) result[0])) {
					secQuestionColMap.get((Long) result[0]).put((long) result[1], (String) result[2]);
				} else {
					Map<Long, String> quesColMap = new HashMap<>();
					quesColMap.put((long) result[1], (String) result[2]);
					secQuestionColMap.put((Long) result[0], quesColMap);
				}
			});
		}
		return secQuestionColMap;
	}

	private Map<String, QueriesVo> getAllSelectQueries() {
		try {
			Map<String, QueriesVo> queryMap = new HashMap<>();
			List<String> entityList = questionnaireDAO.getAllEntityTypes();
			for (String entityType : entityList) {
				QueriesVo queriesVo = new QueriesVo();
				QuestionnaireProperties prop = quesProps.get(entityType);
				Map<Long, String> secIdQueryMap = new HashMap<>();
				Map<Long, List<Long>> secIdQuesMap = new HashMap<>();
				Map<Long, Map<Long, String>> secQuestionColMap = getColumnNamesForQuesId(entityType);

				for (SectionProperties secProp : prop.getSectionProperties()) {
					String tableName = "";
					if (prop.isSeparateSectionTable()) {
						tableName = secProp.getResponseTable();
					} else {
						tableName = prop.getResponseTableName();
					}
					Map<Long, String> quesColMap = secQuestionColMap.get(secProp.getSectionId());
					List<String> columnList = new ArrayList<>();
					List<Long> quesList = new ArrayList<>();
					for (Map.Entry<Long, String> entry : quesColMap.entrySet()) {
						columnList.add(entry.getValue());
						quesList.add(entry.getKey());
					}
					String query = "SELECT " + String.join(",", columnList) + " FROM " + tableName;
					secIdQueryMap.put(secProp.getSectionId(), query);
					secIdQuesMap.put(secProp.getSectionId(), quesList);
				}

				queriesVo.setSecQueryMap(secIdQueryMap);
				queriesVo.setSecQuestionMap(secIdQuesMap);
				queryMap.put(entityType, queriesVo);
			}
			return queryMap;
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap<>();
		}
	}

	private Map<String, QuestionResponse> getQuestionniareJsonMap() {
		try {
			Map<String, QuestionResponse> jsonMap = new HashMap<>();
			List<String> entityList = questionnaireDAO.getAllEntityTypes();
			for (String entityType : entityList) {
				QuestionRequest request = new QuestionRequest();
				request.setEntityType(entityType);
				List<Long> nextQuestion = new ArrayList<>();
				nextQuestion.add(Long.valueOf(0));
				request.setNextQuestion(nextQuestion);
				jsonMap.put(entityType, retriveSingleQuestion(request));
			}

			return jsonMap;
		} catch (Exception e) {
			e.printStackTrace();
			return new HashMap<>();
		}
	}

	public QuestionResponse retriveQuestionJson(String entityType, String ucifId,
			Map<String, QuestionnaireProperties> quesProps) {
		try {

			if (StringUtils.isEmpty(ucifId)) {
				return questionnaireJsonMap.get(entityType);
			} else {
				final QuestionResponse resp = questionnaireJsonMap.get(entityType);
				QuestionResponse editResp = new QuestionResponse();
				editResp.setQuestionnaireProperty(resp.getQuestionnaireProperty());
				editResp.setTypeOfDisplay(resp.getTypeOfDisplay());
				QuestionnaireProperties prop = quesProps.get(entityType);
				QueriesVo queriesVo = questionQueryMap.get(entityType);
				List<SectionDetails> sectionList = new ArrayList<>();
				for (SectionDetails sectionDetails : resp.getSectionDetails()) {
					SectionDetails newSection = new SectionDetails();
					newSection.setMultipleResponses(sectionDetails.isMultipleResponses());
					newSection.setSectionId(sectionDetails.getSectionId());
					newSection.setSectionName(sectionDetails.getSectionName());
					newSection.setSectionOrder(sectionDetails.getSectionOrder());
					List<SubSectionDetails> subSectionDetailsList = new ArrayList<>();
					SubSectionDetails subSection = new SubSectionDetails();
					List<QuestionDTO> questionDtoList = new ArrayList<>();
					for (QuestionDTO questionDto : sectionDetails.getSubSectionDetails().get(0).getComponentDetails()) {
						QuestionDTO newQuesDto = new QuestionDTO();
						newQuesDto.setExtendedAttrVo(questionDto.getExtendedAttrVo());
						newQuesDto.setGenericUIFieldValidationList(questionDto.getGenericUIFieldValidationList());
						newQuesDto.setOptionType(questionDto.getOptionType());
						newQuesDto.setQuestionType(questionDto.getQuestionType());
						newQuesDto.setQuestion(questionDto.getQuestion());
						newQuesDto.setQuestionId(questionDto.getQuestionId());
						newQuesDto.setQuestionDesc(questionDto.getQuestionDesc());
						for (OptionDTO option : questionDto.getOptionMap()) {
							OptionDTO newOption = new OptionDTO();

							newOption.setOptionDesc(option.getOptionDesc());
							newOption.setOption(option.getOption());
							newOption.setOptionId(option.getOptionId());
							newOption.setIsSelected(Boolean.TRUE);

							newQuesDto.getOptionMap().add(newOption);
						}
						questionDtoList.add(newQuesDto);
					}
					subSection.setComponentDetails(questionDtoList);
					subSection.setDeleteFlag(Boolean.FALSE);
					subSectionDetailsList.add(subSection);
					newSection.setSubSectionDetails(subSectionDetailsList);

					for (SectionProperties secProp : prop.getSectionProperties()) {

						if (secProp.getSectionId() == newSection.getSectionId()) {
							List<Object[]> results = questionnaireDAO.getSectionQueryresult(
									queriesVo.getSecQueryMap().get(secProp.getSectionId()), ucifId);
							if (!secProp.isMultipleResponseFlag()) {
								Map<Long, String> questionAnsMap = new HashMap<>();
								for (int i = 0; i < (queriesVo.getSecQuestionMap().get(secProp.getSectionId()))
										.size(); i++) {
									questionAnsMap.put(
											(queriesVo.getSecQuestionMap().get(secProp.getSectionId())).get(i),
											results.get(0)[i].toString());
								}
								for (QuestionDTO questionDto : newSection.getSubSectionDetails().get(0)
										.getComponentDetails()) {
									for (OptionDTO optionDto : questionDto.getOptionMap()) {
										if (questionDto.getOptionType().equals(OptionTypes.I.toString())) {
											optionDto.setOptionDesc(questionAnsMap.get(questionDto.getQuestionId()));
										} else {
											if (questionAnsMap.get(questionDto.getQuestionId())
													.equals(optionDto.getOptionDesc())
													|| questionAnsMap.get(questionDto.getQuestionId())
															.equals(optionDto.getOption())) {
												optionDto.setIsSelected(Boolean.TRUE);
											} else {
												optionDto.setIsSelected(Boolean.FALSE);
											}
										}
									}
								}

							} else {
								List<Map<Long, String>> questionAnsMapList = new ArrayList<>();
								for (Object[] result : results) {
									Map<Long, String> questionAnsMap = new HashMap<>();
									for (int i = 0; i < (queriesVo.getSecQuestionMap().get(secProp.getSectionId()))
											.size(); i++) {
										questionAnsMap.put(
												(queriesVo.getSecQuestionMap().get(secProp.getSectionId())).get(i),
												result[i] != null ? result[i].toString() : null);
									}
									questionAnsMapList.add(questionAnsMap);
								}
								for (QuestionDTO questionDto : newSection.getSubSectionDetails().get(0)
										.getComponentDetails()) {
									for (OptionDTO optionDto : questionDto.getOptionMap()) {
										if (questionDto.getOptionType().equals("I")) {
											optionDto.setOptionDesc(
													questionAnsMapList.get(0).get(questionDto.getQuestionId()));
										} else {
											if (questionAnsMapList.get(0).get(questionDto.getQuestionId())
													.equals(optionDto.getOptionDesc())
													|| questionAnsMapList.get(0).get(questionDto.getQuestionId())
															.equals(optionDto.getOption())) {
												optionDto.setIsSelected(Boolean.TRUE);
											} else {
												optionDto.setIsSelected(Boolean.FALSE);
											}
										}
									}
								}

								for (int i = 1; i < questionAnsMapList.size(); i++) {
									SubSectionDetails editedSubSection = new SubSectionDetails();
									List<QuestionDTO> newQuestionDtoList = new ArrayList<>();
									for (QuestionDTO questionDto : newSection.getSubSectionDetails().get(0)
											.getComponentDetails()) {
										QuestionDTO newQuesDto = new QuestionDTO();
										newQuesDto.setExtendedAttrVo(questionDto.getExtendedAttrVo());
										newQuesDto.setGenericUIFieldValidationList(
												questionDto.getGenericUIFieldValidationList());
										newQuesDto.setOptionType(questionDto.getOptionType());
										newQuesDto.setQuestionType(questionDto.getQuestionType());
										newQuesDto.setQuestion(questionDto.getQuestion());
										newQuesDto.setQuestionId(questionDto.getQuestionId());
										newQuesDto.setQuestionDesc(questionDto.getQuestionDesc());
										for (OptionDTO option : questionDto.getOptionMap()) {
											OptionDTO newOption = new OptionDTO();
											newOption.setOption(option.getOption());
											newOption.setOptionId(option.getOptionId());
											if (questionDto.getOptionType().equals(OptionTypes.I.toString())) {
												newOption.setOptionDesc(
														questionAnsMapList.get(i).get(questionDto.getQuestionId()));
											} else {
												newOption.setOptionDesc(option.getOptionDesc());

												if (questionAnsMapList.get(i).get(questionDto.getQuestionId())
														.equals(newOption.getOptionDesc())
														|| questionAnsMapList.get(i).get(questionDto.getQuestionId())
																.equals(newOption.getOption())) {
													newOption.setIsSelected(Boolean.TRUE);
												} else {
													newOption.setIsSelected(Boolean.FALSE);
												}

											}
											newQuesDto.getOptionMap().add(newOption);
										}

										newQuestionDtoList.add(newQuesDto);

									}
									editedSubSection.setComponentDetails(newQuestionDtoList);
									editedSubSection.setDeleteFlag(Boolean.FALSE);
									newSection.getSubSectionDetails().add(editedSubSection);
								}
							}
						}
					}

					sectionList.add(newSection);
				}
				editResp.setSectionDetails(sectionList);
				return editResp;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new QuestionResponse();
		}

	}

	public Map<Long, List<QuestionMasterValidationBean>> getValdationList() {
		Map<Long, List<QuestionMasterValidationBean>> mapValidationsByQuestionnaireId = new HashMap<>();
		List<QuestionMasterValidationBean> validationList = new ArrayList<>();
		List<QuestionMasterValidation> validations = questionnaireDAO.getAllQuestionMasterValidations();
		System.out.println("# Count of QuestionMasterValidation: " + validations.size());
		if (!CollectionUtil.isEmpty(validations)) {
			validations.forEach(entity -> {
				if(entity != null)
					validationList.add(entity.toBean());
			});

			for (QuestionMasterValidationBean vo : validationList) {
				if(!mapValidationsByQuestionnaireId.containsKey(vo.getQuestionMasterId())) { //vo.getQuestionnaireId())) {
					mapValidationsByQuestionnaireId.put(vo.getQuestionMasterId(), new ArrayList<QuestionMasterValidationBean>());
				}
				mapValidationsByQuestionnaireId.get(vo.getQuestionMasterId()).add(vo);
			}
		}
		
		return mapValidationsByQuestionnaireId;
	}
	
	private Map<Long, List<ComponentMetadataDTO>> getComponentMetadata() {
		Map<Long, List<ComponentMetadataDTO>> componentMetadataMap = new HashMap<>();
		List<ComponentMetadataDTO> componentMetadataList = new ArrayList<>();
		List<ComponentMetadata> results = questionnaireDAO.getComponentMetadata();
		if (!CollectionUtil.isEmpty(results)) {
			results.forEach(result -> {
				ComponentMetadataDTO dto = new ComponentMetadataDTO();
				dto.setComponentMetadataId(result.getComponentMetadataId());
				dto.setQuestionMasterId(result.getQuestionMasterId());
				dto.setPropType(result.getComponentPropType());
				dto.setPropVal(result.getComponentPropVal());
				componentMetadataList.add(dto);
			});
			
			for (ComponentMetadataDTO dto: componentMetadataList) {
				if (componentMetadataMap.containsKey(dto.getQuestionMasterId())) {
					componentMetadataMap.get(dto.getQuestionMasterId()).add(dto);
				} else {
					List<ComponentMetadataDTO> compMetadataList = new ArrayList<>();
					compMetadataList.add(dto);
					componentMetadataMap.put(dto.getQuestionMasterId(), compMetadataList);
				}
			}
		}
		return componentMetadataMap;
	}
	
	private Map<Long, Long> getQuestionRemarkMap() {
		Map<Long, Long> questRemarkMap = new HashMap<>();
		
		List<QuestionRemarkMap> res = questionnaireDAO.getQuestionRemarkMap();
		if (!CollectionUtil.isEmpty(res)) {
			res.forEach(data -> {
				questRemarkMap.put(data.getQuestionMasterId(), data.getRemarkId());
			});
		}

		return questRemarkMap;
	}

	public Map<String, Map<Locale, String>> getMessageMap() {
		Map<String, Map<Locale, String>> mapDetails = new HashMap<>();
		List<Object[]> results = questionnaireDAO.getDescriptions();
		List<QuestionDescVo> voList = new ArrayList<>();
		try {
			if (!CollectionUtils.isEmpty(results)) {
				results.forEach(result -> {
					QuestionDescVo vo = new QuestionDescVo();
					vo.setMsgcode((String) result[0]);
					vo.setMsgDesc((String) result[1]);
					vo.setMsgLang((String) result[2]);
					voList.add(vo);
				});
			}
			for (QuestionDescVo questionVo : voList) {
				Map<Locale, String> map1 = new HashMap<>();
				map1.put(new Locale(questionVo.getMsgLang()), questionVo.getMsgDesc());

				if (mapDetails.get(questionVo.getMsgcode()) == null) {
					mapDetails.put(questionVo.getMsgcode(), map1);
				} else {
					mapDetails.get(questionVo.getMsgcode()).put(new Locale(questionVo.getMsgLang()),
							questionVo.getMsgDesc());
				}
			}
		} catch (Exception e) {
			logger.error("Error on QuestionnaireService :: getMessageMap: " + e.getMessage());
		}
		
		return mapDetails;
	}

	public List<QuestionDTO> retrieveQuestions(String entityType) {

		Locale locale = new Locale("en_US");

		List<Object[]> results = questionnaireDAO.getQuestionaireData(entityType);
		Map<Long, QuestionDTO> questionMap = new LinkedHashMap<>();
		List<QuestionDTO> questionList = new ArrayList<>();
		Map<Long, Long> questionOrder = new TreeMap<>();
		Map<String, Map<Locale, String>> desc = infoMap;
		try {
			results.forEach(result -> {
				BigDecimal orderId = (BigDecimal) result[6];

				if (!questionOrder.containsKey(orderId.longValue())) {
					questionOrder.put(orderId.longValue(), (Long) result[0]);
				}
				if ("Y".equalsIgnoreCase((String) result[12])) {
					List<Object[]> dynamicOptionsList = questionnaireDAO.getDynamicOptions((String) result[13]);
					for (Object[] singleOption : dynamicOptionsList) {
						OptionDTO option = new OptionDTO();
						option.setOption((String) singleOption[0]);
						option.setOptionDesc((String) singleOption[1]);
						option.setIsLeaf(Boolean.TRUE);
						option.setOptionId(Long.valueOf(dynamicOptionsList.indexOf(singleOption)));

						QuestionDTO question;

						if (questionMap.get((Long) result[0]) != null) {
							question = questionMap.get((Long) result[0]);
							question.getOptionMap().add(option);

						} else {
							question = new QuestionDTO();
							question.setQuestionId((Long) result[0]);
							question.setQuestion((String) result[1]);
							if (!CollectionUtils.isEmpty(desc)) {
								question.setQuestionDesc((String) desc.get(result[1]).get(locale));
								question.setSectionName((String) desc.get(result[15]).get(locale));
							}
							question.setOptionType((String) result[7]);
							question.setQuestionType((String) result[8]);
							question.setFormName((String) result[9]);
							question.setIsStatic((String) result[10]);
							question.setSectionId((long) result[14]);
							question.setSectionOrder((long) result[16]);
							if ("ED".equalsIgnoreCase((String) result[17])) {
								question.setTypeOfDisplay(TypeOfDisplay.ENABLE_DISABLE);
							} else {
								question.setTypeOfDisplay(TypeOfDisplay.HIDE_SHOW);
							}
							if ("Y".equalsIgnoreCase((String) result[18])) {
								question.setMultipleResponses(Boolean.TRUE);
							}
							if ("Y".equalsIgnoreCase((String) result[11])) {
								question.setIsDisplayNone(Boolean.FALSE);
							} else {
								question.setIsDisplayNone(Boolean.TRUE);
							}

							question.getOptionMap().add(option);
							questionMap.put(question.getQuestionId(), question);
						}
					}

				} else {
					OptionDTO option = new OptionDTO();
					option.setOption((String) result[2]);
					if (!CollectionUtils.isEmpty(desc)) {
						option.setOptionDesc(((String) desc.get(result[2]).get(locale)));
					}
					if ("Y".equalsIgnoreCase((String) result[3])) {
						option.setIsLeaf(Boolean.TRUE);
					} else {
						option.setIsLeaf(Boolean.FALSE);
					}

					if (result[4] != null)
						option.setNextQuestion(((Long) result[4]).toString());

					option.setOptionId((Long) result[5]);

					QuestionDTO question;

					if (questionMap.get((Long) result[0]) != null) {
						question = questionMap.get((Long) result[0]);
							for (Iterator<OptionDTO> it = question.getOptionMap().iterator(); it.hasNext(); ) {
								OptionDTO optionDTOTemp = it.next();
						        if (optionDTOTemp.equals(option)) {
						        	optionDTOTemp.setNextQuestion(option.getNextQuestion()+","+optionDTOTemp.getNextQuestion());
						   
						        }
						    }
						question.getOptionMap().add(option);
					} else {
						question = new QuestionDTO();
						question.setQuestionId((Long) result[0]);
						question.setQuestion((String) result[1]);
						if (!CollectionUtils.isEmpty(desc)) {
							question.setQuestionDesc((String) desc.get(result[1]).get(locale));
							question.setSectionName((String) desc.get(result[15]).get(locale));
						}
						question.setOptionType((String) result[7]);
						question.setQuestionType((String) result[8]);
						question.setFormName((String) result[9]);
						question.setIsStatic((String) result[10]);
						question.setSectionId((long) result[14]);
						question.setSectionOrder((long) result[16]);
						if ("ED".equalsIgnoreCase((String) result[17])) {
							question.setTypeOfDisplay(TypeOfDisplay.ENABLE_DISABLE);
						} else {
							question.setTypeOfDisplay(TypeOfDisplay.HIDE_SHOW);
						}
						if ("Y".equalsIgnoreCase((String) result[18])) {
							question.setMultipleResponses(Boolean.TRUE);
						}
						if ("Y".equalsIgnoreCase((String) result[11])) {
							question.setIsDisplayNone(Boolean.FALSE);
						} else {
							question.setIsDisplayNone(Boolean.TRUE);
						}

						question.getOptionMap().add(option);
						questionMap.put(question.getQuestionId(), question);
					}
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error occured QuestionnaireService :: retrieveQuestions: " + e.getMessage());
		}

		List<Long> keyList = new ArrayList<>(questionOrder.keySet().size());
		keyList.addAll(questionOrder.keySet());
		Collections.sort(keyList);

		for (Object key : keyList) {
			questionList.add(questionMap.get(questionOrder.get(key)));
		}

		return questionList;
	}

	public Map<String, String> getColumnsAndLogicalNames() {

		Map<String, String> map = new LinkedHashMap<>();

		List<Object[]> results = questionnaireDAO.extensibleAttributes();
		if (!CollectionUtil.isEmpty(results)) {
			results.forEach(result -> map.put((String) result[1], (String) result[0]));
		}
		return map;
	}

	public List<ExtendedValues> getLogicalNamesAndValues(long questionid, Map<String, String> map) {
		List<ExtendedValues> extendedList = new ArrayList<>();
		List<String> result = questionnaireDAO.extensibleValue(questionid, map.keySet());
		int i = 0;
		if (!CollectionUtil.isEmpty(result)) {
			for (String logicalName : map.values()) {
				ExtendedValues val = new ExtendedValues();
				val.setName(logicalName);
				val.setValue(result.get(i));
				extendedList.add(val);
				i++;
			}
		}

		return extendedList;
	}

	public QuestionResponse retriveSingleQuestion(QuestionRequest request) {

		Locale locale = new Locale("en_US");

		Map<Long, List<QuestionAnswerVo>> answeredOptionMap = new HashMap<>();
		if (request.getPrimaryIdentifier() != null) {
			answeredOptionMap = getQuestionAnswerFromDB(request);
		}
		QuestionDTO questionDto = new QuestionDTO();
		QuestionResponse response = new QuestionResponse();
		List<QuestionDTO> questionList = retrieveQuestions(request.getEntityType());
		List<QuestionDTO> questionResponseList = new ArrayList<>();
		Map<String, String> columnMap = getColumnsAndLogicalNames();
		for (Long nxtQues : request.getNextQuestion()) {
			for (QuestionDTO question : questionList) {
				List<ExtendedValues> values = getLogicalNamesAndValues(question.getQuestionId(), columnMap);

				updateOptionSelectedFlag(question, answeredOptionMap);
				question.setExtendedAttrVo(values);
				convertQuestionType(question, answeredOptionMap);
				if (!CollectionUtil.isEmpty(mapValidationsByQuestionnaireId.get(question.getQuestionId()))) {
					question.setGenericUIFieldValidationList(mapValidationsByQuestionnaireId.get(question.getQuestionId()));
					for (QuestionMasterValidationBean validVo : question.getGenericUIFieldValidationList()) {
						if (!CollectionUtils.isEmpty(infoMap)) {
							validVo.setErrorMsg(((String) infoMap.get(validVo.getErrorCode()).get(locale)));
						}
					}
				} else {
					List<QuestionMasterValidationBean> vo = new ArrayList<>();
					question.setGenericUIFieldValidationList(vo);
				}

				switch (question.getIsStatic()) {
				case "N": {
					response.setQuestionnaireProperty("dynamic");
					if (nxtQues == 0) {
						questionResponseList.add(questionList.get(0));
						break;
					}
					if (nxtQues == question.getQuestionId()) {
						questionResponseList.add(question);
					}
				}
					break;
				default: {
					response.setQuestionnaireProperty("static");
					questionDto = question;
					questionResponseList.add(questionDto);
				}
					break;
				}
			}

		}

		List<SubSectionDetails> subSectionList = convertQuesDtoListToSubsectionList(questionResponseList);
		List<SectionDetails> sectionList = convertSubSectionListToSectionList(subSectionList);
		response.setSectionDetails(sectionList);
		response.setTypeOfDisplay(questionResponseList.get(0).getTypeOfDisplay());

		return response;

	}

	private List<SubSectionDetails> convertQuesDtoListToSubsectionList(List<QuestionDTO> questionResponseList) {
		Map<Long, List<QuestionDTO>> map = new LinkedHashMap<>();
		List<SubSectionDetails> subSectionList = new ArrayList<>();
		for (QuestionDTO quesDto : questionResponseList) {
			if (map.containsKey(quesDto.getSectionId())) {
				map.get(quesDto.getSectionId()).add(quesDto);
			} else {
				List<QuestionDTO> dtoList = new ArrayList<>();
				dtoList.add(quesDto);
				map.put(quesDto.getSectionId(), dtoList);
			}
		}
		for (Map.Entry<Long, List<QuestionDTO>> entry : map.entrySet()) {
			SubSectionDetails section = new SubSectionDetails();
			section.setSectionId(entry.getKey());
			section.setSectionName(entry.getValue().get(0).getSectionName());
			section.setSectionOrder(entry.getValue().get(0).getSectionOrder());
			section.setMultipleResponses(entry.getValue().get(0).isMultipleResponses());
			section.setComponentDetails(entry.getValue());
			subSectionList.add(section);
		}
		Collections.sort(subSectionList, new SortBySortOrder());
		return subSectionList;
	}

	private List<SectionDetails> convertSubSectionListToSectionList(List<SubSectionDetails> subSectionList) {
		List<SectionDetails> sectionDetails = new ArrayList<>();
		for (SubSectionDetails subSection : subSectionList) {
			SectionDetails section = new SectionDetails();
			List<SubSectionDetails> subList = new ArrayList<>();
			section.setSectionId(subSection.getSectionId());
			section.setSectionName(subSection.getSectionName());
			section.setMultipleResponses(subSection.isMultipleResponses());
			subList.add(subSection);
			section.setSubSectionDetails(subList);
			sectionDetails.add(section);
		}
		return sectionDetails;
	}

	private void updateOptionSelectedFlag(QuestionDTO question, Map<Long, List<QuestionAnswerVo>> answeredOptionMap) {
		if (!CollectionUtils.isEmpty(answeredOptionMap.get(question.getQuestionId()))) {
			for (OptionDTO option : question.getOptionMap()) {
				for (QuestionAnswerVo ans : answeredOptionMap.get(question.getQuestionId())) {
					if (((Long) ans.getAnswerId()).equals(option.getOptionId())) {
						option.setIsSelected(Boolean.TRUE);
					} else {
						option.setIsSelected(Boolean.FALSE);
					}
				}
			}
		}

	}

	private void convertQuestionType(QuestionDTO question, Map<Long, List<QuestionAnswerVo>> answeredOptionMap) {
		switch (question.getOptionType()) {
		case "M":
			question.setQuestionType(OptionTypes.S.getAction());
			break;
		case "S":
			question.setQuestionType(OptionTypes.S.getAction());
			break;
		case "R":
			question.setQuestionType(OptionTypes.R.getAction());
			break;
		case "C":
			question.setQuestionType(OptionTypes.C.getAction());
			break;
		case "I":
			question.setQuestionType(OptionTypes.I.getAction());
			Collection<OptionDTO> options = question.getOptionMap();
			int i = 0;
			for (OptionDTO option : options) {
				if (answeredOptionMap.get(question.getQuestionId()) != null) {
					option.setOptionDesc(answeredOptionMap.get(question.getQuestionId()).get(i).getAnswer());
					i++;
				}
			}
			break;
		case "W":
			question.setQuestionType(OptionTypes.W.getAction());
			break;
		case "L":
			question.setQuestionType(OptionTypes.L.getAction());
			break;
		case "D":
			question.setQuestionType(OptionTypes.D.getAction());
			break;
		case "B":
			question.setQuestionType(OptionTypes.B.getAction());
			break;
		case "E":
			question.setQuestionType(OptionTypes.E.getAction());
			Collection<OptionDTO> optionsE = question.getOptionMap();
			int ie = 0;
			for (OptionDTO option : optionsE) {
				if (answeredOptionMap.get(question.getQuestionId()) != null) {
					option.setOptionDesc(answeredOptionMap.get(question.getQuestionId()).get(ie).getAnswer());
					ie++;
				}
			}
			break;			
		default:
			question.setQuestionType(OptionTypes.S.getAction());
			break;
		}
	}

	private Map<Long, List<QuestionAnswerVo>> getQuestionAnswerFromDB(QuestionRequest request) {
		Map<Long, List<QuestionAnswerVo>> answeredOptionMap = new HashMap<>();
		List<QuestionAnswerVo> voList = new ArrayList<>();
		List<Object[]> answers = questionnaireDAO.getAnswers(request.getPrimaryIdentifier(), request.getEntityType());
		if (!CollectionUtils.isEmpty(answers)) {
			answers.forEach(row -> voList.add(getQuestionAnswerVo(row)));
		}
		for (QuestionAnswerVo vo : voList) {
			if (answeredOptionMap.containsKey(vo.getQuestionId())) {
				answeredOptionMap.get(vo.getQuestionId()).add(vo);
			} else {
				List<QuestionAnswerVo> answerList = new ArrayList<>();
				answerList.add(vo);
				answeredOptionMap.put(vo.getQuestionId(), answerList);
			}
		}
		return answeredOptionMap;
	}

	private QuestionAnswerVo getQuestionAnswerVo(Object[] row) {
		QuestionAnswerVo vo = new QuestionAnswerVo();
		vo.setAnswerId(row[1] != null ? ((BigDecimal) row[1]).longValue() : 0);
		vo.setQuestionId(row[0] != null ? ((BigDecimal) row[0]).longValue() : 0);
		vo.setAnswer(row[2] != null ? ((String) row[2]) : "");
		return vo;
	}

}
