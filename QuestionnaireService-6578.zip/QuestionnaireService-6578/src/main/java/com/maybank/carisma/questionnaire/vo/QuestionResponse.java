package com.maybank.carisma.questionnaire.vo;

import java.io.Serializable;
import java.util.List;

import com.maybank.carisma.vo.common.BaseResponseObject;

public class QuestionResponse extends BaseResponseObject implements Serializable {

	private static final long serialVersionUID = 7611992051888558126L;

	private String questionnaireProperty;

	private TypeOfDisplay typeOfDisplay;

	private List<SectionDetails> sectionDetails;

	public String getQuestionnaireProperty() {
		return questionnaireProperty;
	}

	public void setQuestionnaireProperty(String questionType) {
		this.questionnaireProperty = questionType;
	}

	public TypeOfDisplay getTypeOfDisplay() {
		return typeOfDisplay;
	}

	public void setTypeOfDisplay(TypeOfDisplay typeOfDisplay) {
		this.typeOfDisplay = typeOfDisplay;
	}

	public List<SectionDetails> getSectionDetails() {
		return sectionDetails;
	}

	public void setSectionDetails(List<SectionDetails> sectionDetails) {
		this.sectionDetails = sectionDetails;
	}

	// enhancement

	private long requestId;

	private long questionnaireId;

	private String questionnaireName;
	
	private String moduleName;

	private long nextSection;

	private List<SelectOption> selectOptions;

	private List<QuestionAnswerDTO> questionAnswerDTOs;

	private QuestionAnswerResponseDTO questionAnswerResponseDTO;

	private String serviceStatus;

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public long getQuestionnaireId() {
		return questionnaireId;
	}

	public void setQuestionnaireId(long questionnaireId) {
		this.questionnaireId = questionnaireId;
	}

	public String getQuestionnaireName() {
		return questionnaireName;
	}

	public void setQuestionnaireName(String questionnaireName) {
		this.questionnaireName = questionnaireName;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public long getNextSection() {
		return nextSection;
	}

	public void setNextSection(long nextSection) {
		this.nextSection = nextSection;
	}

	public List<SelectOption> getSelectOptions() {
		return selectOptions;
	}

	public void setSelectOptions(List<SelectOption> selectOptions) {
		this.selectOptions = selectOptions;
	}

	public List<QuestionAnswerDTO> getQuestionAnswerDTOs() {
		return this.questionAnswerDTOs;
	}

	public void setQuestionAnswerDTOs(List<QuestionAnswerDTO> questionAnswerDTOs) {
		this.questionAnswerDTOs = questionAnswerDTOs;
	}

	public String getServiceStatus() {
		return serviceStatus;
	}

	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}

	public QuestionAnswerResponseDTO getQuestionAnswerResponseDTO() {
		return questionAnswerResponseDTO;
	}

	public void setQuestionAnswerResponseDTO(QuestionAnswerResponseDTO questionAnswerResponseDTO) {
		this.questionAnswerResponseDTO = questionAnswerResponseDTO;
	}

}
