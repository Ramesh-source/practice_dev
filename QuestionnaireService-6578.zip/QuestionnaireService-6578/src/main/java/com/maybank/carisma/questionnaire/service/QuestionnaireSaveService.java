package com.maybank.carisma.questionnaire.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.maybank.carisma.dao.commonQuestionnaire.QuestionnaireSaveDao;
import com.maybank.carisma.questionnaire.vo.QuestionAnswerVo;
import com.maybank.carisma.questionnaire.vo.QuestionSaveInfo;
import com.maybank.carisma.questionnaire.vo.QuestionSectionSaveVo;
import com.maybank.carisma.questionnaire.vo.QuestionnaireProperties;
import com.maybank.carisma.questionnaire.vo.QuestionnaireSaveRequest;
import com.maybank.carisma.questionnaire.vo.SectionProperties;

@Service
public class QuestionnaireSaveService {

	private static final Logger logger = LogManager.getLogger(QuestionnaireSaveService.class);

	private Map<Long, String> quesIdColumnMap;

	@Autowired
	QuestionnaireSaveDao questionnaireServiceDao;

	@PostConstruct
	@Transactional
	public void init() {
		quesIdColumnMap = getColumnNamesForQuesId();
	}

	private Map<Long, String> getColumnNamesForQuesId() {
		List<Object[]> results = questionnaireServiceDao.getTableNamesForAllQuesId();
		Map<Long, String> map = new HashMap<>();
		if (!CollectionUtils.isEmpty(results)) {
			results.forEach(result -> {
				map.put((long) result[0], (String) result[1]);
			});
		}

		return map;
	}

	public Map<String, QuestionnaireProperties> getQuestionnaireProperties() {

		List<Object[]> results = questionnaireServiceDao.getQuestionnaireProperties();
		Map<String, List<SectionProperties>> sectionMap = new HashMap<>();
		Map<String, QuestionnaireProperties> questionPropMap = new HashMap<>();
		if (!CollectionUtils.isEmpty(results)) {

			results.forEach(result -> {
				SectionProperties sec = new SectionProperties();
				sec.setResponseTable((String) result[6]);
				sec.setSectionId((long) result[7]);
				if ("Y".equalsIgnoreCase((String) result[4])) {
					sec.setMultipleResponseFlag(Boolean.TRUE);
				} else {
					sec.setMultipleResponseFlag(Boolean.FALSE);
				}
				sec.setResponseStyle((String) result[5]);

				if (sectionMap.containsKey((String) result[0])) {
					sectionMap.get((String) result[0]).add(sec);
				} else {
					List<SectionProperties> seclist = new ArrayList<>();
					seclist.add(sec);
					sectionMap.put((String) result[0], seclist);
				}
			});

			results.forEach(result -> {
				QuestionnaireProperties vo = new QuestionnaireProperties();
				vo.setQuestionnaireName((String) result[0]);
				vo.setResponseTableName((String) result[1]);
				vo.setResponseStyle((String) result[2]);
				if ("Y".equalsIgnoreCase((String) result[3])) {
					vo.setSeparateSectionTable(Boolean.TRUE);
				} else {
					vo.setSeparateSectionTable(Boolean.FALSE);
				}
				vo.setSectionProperties(sectionMap.get((String) result[0]));
				questionPropMap.put(vo.getQuestionnaireName(), vo);
			});
		}
		return questionPropMap;
	}

	@Transactional
	public void saveQuestionAnswer(QuestionnaireSaveRequest request, Map<String, QuestionnaireProperties> quesProps) {
		QuestionnaireProperties prop = quesProps.get(request.getQuestionnaireName());
		if (!prop.isSeparateSectionTable()) {
			String tableName = prop.getResponseTableName();
			for (QuestionSaveInfo info : request.getQuestionInfo()) {
				saveRowQuestionnaire(info.getSectionSaveVo().get(0), tableName, request);
			}
		} else {
			for (QuestionSaveInfo info : request.getQuestionInfo()) {
				for (SectionProperties section : prop.getSectionProperties()) {
					if (section.getSectionId() == info.getSectionId()) {
						String tableName = section.getResponseTable();
						if ("R".equalsIgnoreCase(section.getResponseStyle())) {

							saveRowQuestionnaire(info.getSectionSaveVo().get(0), tableName, request);
						} else {
							if (!section.isMultipleResponseFlag()) {
								saveColumnQuestionnaire(info.getSectionSaveVo().get(0), tableName, request);
							} else {
								for (QuestionSectionSaveVo sectionVo : info.getSectionSaveVo()) {
									saveColumnQuestionnaire(sectionVo, tableName, request);
								}
							}
						}
					}
				}
			}
		}
	}

	private void saveColumnQuestionnaire(QuestionSectionSaveVo sectionSaveVo, String tableName,
			QuestionnaireSaveRequest request) {
		List<String> columnNames = new ArrayList<>();
		List<Object> columnValues = new ArrayList<>();
		for (QuestionAnswerVo ansVo : sectionSaveVo.getAnsVo()) {
			if (quesIdColumnMap.get(ansVo.getQuestionId()) == null) {
				continue;
			}
			columnNames.add(quesIdColumnMap.get(ansVo.getQuestionId()));
			if (ansVo.getAnswerId() != null) {
				columnValues.add(ansVo.getAnswerId());
			} else {
				columnValues.add(ansVo.getAnswer());
			}
		}

		if (sectionSaveVo.getResponseRowId() != null) {
			questionnaireServiceDao.updateColumnQuestionnaire(columnNames, columnValues, tableName,
					request.getPrimaryIdentifier(), request.getQuestionnaireName(), request.getUpdatedBy(),sectionSaveVo.getResponseRowId());
		} else {
			questionnaireServiceDao.insertColumnQuestionnaire(columnNames, columnValues, tableName,
					request.getPrimaryIdentifier(), request.getQuestionnaireName(), request.getCreatedBy());
		}
	}

	public void saveRowQuestionnaire(QuestionSectionSaveVo questionSectionSaveVo, String tableName,
			QuestionnaireSaveRequest request) {
			if (!(StringUtils.isEmpty(tableName))) {
				for (QuestionAnswerVo ansVo : questionSectionSaveVo.getAnsVo()) {
					BigDecimal count = questionnaireServiceDao.updateQuestionNumber(tableName,
							request.getPrimaryIdentifier(), request.getQuestionnaireName(), ansVo.getQuestionId());
					if (count.compareTo(BigDecimal.valueOf(0.0)) > 0) {
						questionnaireServiceDao.updateQuestionnaireInfo(tableName, request.getQuestionnaireName(),
								request.getPrimaryIdentifier(), ansVo.getQuestionId(), ansVo.getAnswerId(),
								ansVo.getAnswer(), request.getUpdatedBy());
					} else {
						questionnaireServiceDao.insertQuestionInfo(tableName, request.getQuestionnaireName(),
								request.getPrimaryIdentifier(), ansVo.getQuestionId(), ansVo.getAnswerId(),
								ansVo.getAnswer(), request.getCreatedBy());
					}
				}
			}
	}

}
