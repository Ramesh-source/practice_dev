package com.maybank.carisma.questionnaire.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the QUESTION_OPTIONS_NAVIGATION database table.
 * 
 */
@Entity
@Table(name = "QUESTION_OPTIONS_NAVIGATION")
public class QuestionOptionsNavigation implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 249830327201617752L;

	@Id
	@SequenceGenerator(name = "questionsNav", sequenceName = "SEQ_QUESTION_OPTIONS_NAV_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "questionsNav")
	@Column(name = "N_QUESTION_OPTIONS_NAV_ID")
	private long nQuestionOptionsNavId;

	// bi-directional many-to-one association to AvlOptionsToQuestion
	@ManyToOne
	@JoinColumn(name = "N_AVL_OPTIONS_TO_QUESTIONS_ID")
	private AvlOptionsToQuestion avlOptionsToQuestion;

	/*
	 * //bi-directional many-to-one association to QuestionMaster
	 * 
	 * @ManyToOne
	 */
	@Column(name = "N_QUESTION_MASTER_ID")
	private Long questionMaster;

	public long getNQuestionOptionsNavId() {
		return this.nQuestionOptionsNavId;
	}

	public void setNQuestionOptionsNavId(long nQuestionOptionsNavId) {
		this.nQuestionOptionsNavId = nQuestionOptionsNavId;
	}

	public AvlOptionsToQuestion getAvlOptionsToQuestion() {
		return this.avlOptionsToQuestion;
	}

	public void setAvlOptionsToQuestion(AvlOptionsToQuestion avlOptionsToQuestion) {
		this.avlOptionsToQuestion = avlOptionsToQuestion;
	}

	public Long getQuestionMaster() {
		return this.questionMaster;
	}

	public void setQuestionMaster(Long questionMaster) {
		this.questionMaster = questionMaster;
	}

}