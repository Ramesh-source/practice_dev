package com.maybank.carisma.questionnaire.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the QUESTION_MASTER database table.
 * 
 */
@Entity
@Table(name = "QUESTION_MASTER")
@NamedQueries({
		@NamedQuery(name="QuestionMaster.findAll", query="SELECT q FROM QuestionMaster q"),
		@NamedQuery(name = QuestionMaster.QUESTION_MASTERS_FOR_SECTION_ID, query = "SELECT qm FROM QuestionMaster qm WHERE qm.sectionId = :sectionId") })
public class QuestionMaster implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 2886063717728999658L;

	public static final String QUESTION_MASTERS_FOR_SECTION_ID = "QUESTION_MASTERS_FOR_SECTION_ID";

	/** The n question master id. */
	@Id
	@SequenceGenerator(name = "questionMaster", sequenceName = "SEQ_QUESTION_MASTER_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "questionMaster")
	@Column(name = "N_QUESTION_MASTER_ID")
	private long nQuestionMasterId;

	/** The v option selection type. */
	@Column(name = "V_OPTION_SELECTION_TYPE")
	private String vOptionSelectionType;

	/** The v question. */
	@Column(name = "V_QUESTION")
	private String vQuestion;

	/** The question type. */
	@Column(name = "QUESTION_TYPE")
	private String questionType;

	/** The form name. */
	@Column(name = "FORM_NAME")
	private String formName;

	@Column(name = "F_IS_DEFAULT_VISIBLE")
	private String isDisplayNone;

	@Column(name = "F_OPTIONS_STATIC")
	private String optionsStatic;

	@Column(name = "V_QUERY")
	private String query;

	@Column(name = "V_RESPONSE_COLUMN_NAME")
	private String responseColumn;

	/** The avl options to questions. */
	// bi-directional many-to-one association to AvlOptionsToQuestion
	@OneToMany(mappedBy = "questionMaster")
	private Set<AvlOptionsToQuestion> avlOptionsToQuestions;

	/** The questionnaire question maps. */
	// bi-directional many-to-one association to QuestionnaireQuestionMap
	@OneToMany(mappedBy = "questionMaster")
	private Set<QuestionnaireQuestionMap> questionnaireQuestionMaps;
	
//	@Column(name="f_is_mandatory")
//	private Character isMandatory;
//	
//
//	/**
//	 * @return the isMandatory
//	 */
//	public Character getIsMandatory() {
//		return isMandatory;
//	}
//
//	/**
//	 * @param isMandatory the isMandatory to set
//	 */
//	public void setIsMandatory(Character isMandatory) {
//		this.isMandatory = isMandatory;
//	}
	
	@Column (name="v_question_tooltip")
	private String questionTooltip;
		

	/**
	 * @return the questionTooltip
	 */
	public String getQuestionTooltip() {
		return questionTooltip;
	}

	/**
	 * @param questionTooltip the questionTooltip to set
	 */
	public void setQuestionTooltip(String questionTooltip) {
		this.questionTooltip = questionTooltip;
	}
	
	/*This code was added on 5th May 2022 to handle Href Link as per request from Score Team */
	@Column (name="v_question_href")
	private String questionHref;
		

	/**
	 * @return the questionHref
	 */
	public String getQuestionHref() {
		return questionHref;
	}

	/**
	 * @param questionHref the questionHref to set
	 */
	public void setQuestionHref(String questionHref) {
		this.questionHref = questionHref;
	}	

	/**
	 * Gets the question type.
	 *
	 * @return the question type
	 */
	public String getQuestionType() {
		return questionType;
	}

	/**
	 * Sets the question type.
	 *
	 * @param questionType the new question type
	 */
	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}

	/**
	 * Gets the form name.
	 *
	 * @return the form name
	 */
	public String getFormName() {
		return formName;
	}

	/**
	 * Sets the form name.
	 *
	 * @param formName the new form name
	 */
	public void setFormName(String formName) {
		this.formName = formName;
	}

	/**
	 * Gets the n question master id.
	 *
	 * @return the n question master id
	 */
	public long getNQuestionMasterId() {
		return this.nQuestionMasterId;
	}

	/**
	 * Sets the n question master id.
	 *
	 * @param nQuestionMasterId the new n question master id
	 */
	public void setNQuestionMasterId(long nQuestionMasterId) {
		this.nQuestionMasterId = nQuestionMasterId;
	}

	/**
	 * Gets the v option selection type.
	 *
	 * @return the v option selection type
	 */
	public String getVOptionSelectionType() {
		return this.vOptionSelectionType;
	}

	/**
	 * Sets the v option selection type.
	 *
	 * @param vOptionSelectionType the new v option selection type
	 */
	public void setVOptionSelectionType(String vOptionSelectionType) {
		this.vOptionSelectionType = vOptionSelectionType;
	}

	/**
	 * Gets the v question.
	 *
	 * @return the v question
	 */
	public String getVQuestion() {
		return this.vQuestion;
	}

	/**
	 * Sets the v question.
	 *
	 * @param vQuestion the new v question
	 */
	public void setVQuestion(String vQuestion) {
		this.vQuestion = vQuestion;
	}

	/**
	 * Gets the avl options to questions.
	 *
	 * @return the avl options to questions
	 */
	public Set<AvlOptionsToQuestion> getAvlOptionsToQuestions() {
		return this.avlOptionsToQuestions;
	}

	/**
	 * Sets the avl options to questions.
	 *
	 * @param avlOptionsToQuestions the new avl options to questions
	 */
	public void setAvlOptionsToQuestions(Set<AvlOptionsToQuestion> avlOptionsToQuestions) {
		this.avlOptionsToQuestions = avlOptionsToQuestions;
	}

	/**
	 * Adds the avl options to question.
	 *
	 * @param avlOptionsToQuestion the avl options to question
	 * @return the avl options to question
	 */
	public AvlOptionsToQuestion addAvlOptionsToQuestion(AvlOptionsToQuestion avlOptionsToQuestion) {
		getAvlOptionsToQuestions().add(avlOptionsToQuestion);
		avlOptionsToQuestion.setQuestionMaster(this);

		return avlOptionsToQuestion;
	}

	/**
	 * Removes the avl options to question.
	 *
	 * @param avlOptionsToQuestion the avl options to question
	 * @return the avl options to question
	 */
	public AvlOptionsToQuestion removeAvlOptionsToQuestion(AvlOptionsToQuestion avlOptionsToQuestion) {
		getAvlOptionsToQuestions().remove(avlOptionsToQuestion);
		avlOptionsToQuestion.setQuestionMaster(null);

		return avlOptionsToQuestion;
	}

	/**
	 * Gets the questionnaire question maps.
	 *
	 * @return the questionnaire question maps
	 */
	public Set<QuestionnaireQuestionMap> getQuestionnaireQuestionMaps() {
		return this.questionnaireQuestionMaps;
	}

	/**
	 * Sets the questionnaire question maps.
	 *
	 * @param questionnaireQuestionMaps the new questionnaire question maps
	 */
	public void setQuestionnaireQuestionMaps(Set<QuestionnaireQuestionMap> questionnaireQuestionMaps) {
		this.questionnaireQuestionMaps = questionnaireQuestionMaps;
	}

	/**
	 * Adds the questionnaire question map.
	 *
	 * @param questionnaireQuestionMap the questionnaire question map
	 * @return the questionnaire question map
	 */
	public QuestionnaireQuestionMap addQuestionnaireQuestionMap(QuestionnaireQuestionMap questionnaireQuestionMap) {
		getQuestionnaireQuestionMaps().add(questionnaireQuestionMap);
		questionnaireQuestionMap.setQuestionMaster(this);

		return questionnaireQuestionMap;
	}

	/**
	 * Removes the questionnaire question map.
	 *
	 * @param questionnaireQuestionMap the questionnaire question map
	 * @return the questionnaire question map
	 */
	public QuestionnaireQuestionMap removeQuestionnaireQuestionMap(QuestionnaireQuestionMap questionnaireQuestionMap) {
		getQuestionnaireQuestionMaps().remove(questionnaireQuestionMap);
		questionnaireQuestionMap.setQuestionMaster(null);

		return questionnaireQuestionMap;
	}

	// enhancement

	@Column(name = "N_QUESTION_ORDER")
	private Integer questionOrder;

	@Column(name = "V_RULE")
	private String rule;

	@Column(name = "V_RULE_PARAMS")
	private String ruleParams;

	public Integer getQuestionOrder() {
		return questionOrder;
	}

	public void setQuestionOrder(Integer questionOrder) {
		this.questionOrder = questionOrder;
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public String getRuleParams() {
		return ruleParams;
	}

	public void setRuleParams(String ruleParams) {
		this.ruleParams = ruleParams;
	}

	public String getIsDisplayNone() {
		return isDisplayNone;
	}

	public void setIsDisplayNone(String isDisplayNone) {
		this.isDisplayNone = isDisplayNone;
	}

	// enhancement

	@Column(name = "N_QUESTIONNAIRE_SECTIONS_ID")
	private Long sectionId;

	public Long getSectionId() {
		return sectionId;
	}

	public void setSectionId(Long sectionId) {
		this.sectionId = sectionId;
	}

	@Override
	public String toString() {
		return "QuestionMaster [nQuestionMasterId=" + nQuestionMasterId + ", vOptionSelectionType="
				+ vOptionSelectionType + ", vQuestion=" + vQuestion + ", questionType=" + questionType + ", formName="
				+ formName + ", isDisplayNone=" + isDisplayNone + ", optionsStatic=" + optionsStatic + ", query="
				+ query + ", responseColumn=" + responseColumn + ", avlOptionsToQuestions=" + avlOptionsToQuestions
				+ ", questionnaireQuestionMaps=" + questionnaireQuestionMaps + ", questionTooltip=" + questionTooltip
				+ ", questionHref=" + questionHref + ", questionOrder=" + questionOrder + ", rule=" + rule
				+ ", ruleParams=" + ruleParams + ", sectionId=" + sectionId + "]";
	}

}
