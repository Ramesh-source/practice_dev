package com.maybank.carisma.questionnaire.enhancement.enumeration.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.maybank.carisma.questionnaire.entity.AvlOptionsToQuestion;
import com.maybank.carisma.questionnaire.entity.QuestionAnswer;
import com.maybank.carisma.questionnaire.entity.QuestionAnswerKey;
import com.maybank.carisma.questionnaire.entity.QuestionMaster;
import com.maybank.carisma.questionnaire.entity.Questionnaire;
import com.maybank.carisma.questionnaire.entity.QuestionnaireSections;

@Repository
public class EnhancedQuestionnaireServiceDAO {

	@PersistenceContext
	protected EntityManager em;

	public long getRequestId() {
		String sql = "select SEQ_QUESTIONNAIRE_REQUEST_ID.NEXTVAL FROM DUAL";
		Query q = em.createNativeQuery(sql);
		long requestId = ((BigDecimal) q.getSingleResult()).longValue();
		return requestId;
	}

	public List<Object[]> getAllQuestionsForQuestionnaireId(long questionnaireId) {
		String query = "SELECT qm.vQuestion, qm.vOptionSelectionType, qs.sectionOrder "
				+ " FROM QuestionMaster qm, QuestionnaireSections qs"
				+ " WHERE qm.sectionId = qs.nQuestionnaireSectionsId"
				+ " AND qs.questionnaire.nQuestionnaireId = :questionnaireId";
		Query q = em.createQuery(query);
		q.setParameter("questionnaireId", questionnaireId);

		List<Object[]> questionIdList = q.getResultList();

		return questionIdList;
	}

	public Boolean checkIfRequestAdded(long requestId) {
		Query q = em.createNamedQuery(QuestionAnswer.GET_COUNT_ON_SECTION_QUESTION_ANSWER);
		q.setParameter("requestId", requestId);
		Long count = (Long) q.getSingleResult();
		if (count > 0) {
			return true;
		}
		return false;
	}

	public int deleteQuestionAnswerByRequestId(long requestId) {
		Query q = em.createNamedQuery(QuestionAnswer.DELETE_SECTION_QUESTION_ANSWER);
		q.setParameter("requestId", requestId);
		return q.executeUpdate();
	}

	public long getQuestionnaireIdForRequestId(long requestId) {
		Query query = em.createNamedQuery(QuestionAnswer.GET_QUESTIONNAIRE_ID_FOR_REQUEST_ID);
		query.setParameter("requestId", requestId);
		Long questionnaireId = (Long) query.getSingleResult();
		return questionnaireId;
	}

	public Questionnaire getQuestionnaire(long questionnaireId) {
		TypedQuery<Questionnaire> query = em.createNamedQuery(Questionnaire.GET_QUESTIONNAIRE, Questionnaire.class);
		query.setParameter("questionnaireId", questionnaireId);
		return query.getSingleResult();
	}

	public List<QuestionnaireSections> getQuestionnaireSections(long questionnaireId, long sectionOrder) {
		TypedQuery<QuestionnaireSections> query = em.createNamedQuery(QuestionnaireSections.GET_QUESTIONNAIRE_SECTIONS_BY_ORDER, QuestionnaireSections.class);
		query.setParameter("questionnaireId", questionnaireId);
		query.setParameter("sectionOrder", sectionOrder);
		return query.getResultList();
	}

	public List<QuestionnaireSections> getQuestionnaireSections(Long questionnaireId) {
		TypedQuery<QuestionnaireSections> query = em.createNamedQuery(QuestionnaireSections.GET_QUESTIONNAIRE_SECTIONS_BY_QUESTIONNAIRE_ID, QuestionnaireSections.class);
		query.setParameter("questionnaireId", questionnaireId);
		return query.getResultList();
	}

	public List<QuestionMaster> getQuestionMastersForSectionId(Long sectionId) {
		TypedQuery<QuestionMaster> query = em.createNamedQuery(QuestionMaster.QUESTION_MASTERS_FOR_SECTION_ID, QuestionMaster.class);
		query.setParameter("sectionId", sectionId);
		return query.getResultList();
	}

	public List<AvlOptionsToQuestion> getAvlOptionsToQuestionForQuestionId(long questionId) {
		TypedQuery<AvlOptionsToQuestion> query = em.createNamedQuery(AvlOptionsToQuestion.GET_OPTIONS_FOR_QUESTION_ID, AvlOptionsToQuestion.class);
		query.setParameter("questionId", questionId);
		return query.getResultList();
	}

	public void updateAnswerWithNull(QuestionAnswer questionAnswer) {
		questionAnswer.setAnswerId(null);
		questionAnswer.setAnswerDesc(null);
		updateQuestionAnswer(questionAnswer);
	}

	public void updateQuestionAnswer(QuestionAnswer questionAnswer) {
		em.merge(questionAnswer);
	}

	public QuestionAnswer getAnswer(QuestionAnswer questionAnswer) {
		TypedQuery<QuestionAnswer> query = em.createNamedQuery(QuestionAnswer.GET_ANSWER, QuestionAnswer.class);
		query.setParameter("requestId", questionAnswer.getQuestionAnswerKey().getRequestId());
		query.setParameter("questionnaireId", questionAnswer.getQuestionAnswerKey().getQuestionnaireId());
		query.setParameter("questionId", questionAnswer.getQuestionAnswerKey().getQuestionId());
		try {
			return query.getSingleResult();
		} catch (NoResultException e) {
			System.out.println("ERR# " + e.getMessage());
		}
		
		return null;
	}

	public void saveQuestionAnswer(QuestionAnswer questionAnswer) {
		try {
			System.out.println(questionAnswer.toString());
			em.persist(questionAnswer);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public QuestionAnswer getSectionQuestionAnswer(QuestionAnswerKey key) {
		return em.find(QuestionAnswer.class, key);
	}

	public List<Questionnaire> getAllQuestionnaire() {
		TypedQuery<Questionnaire> query = em.createNamedQuery(Questionnaire.findAll1, Questionnaire.class);
		return query.getResultList();
	}

	public List<QuestionAnswer> getQuestionAnswerByRequestId(Long requestId) {
		TypedQuery<QuestionAnswer> query = em.createNamedQuery(QuestionAnswer.GET_QUESTION_ANSWER_BY_REQUEST_ID, QuestionAnswer.class);
		query.setParameter("requestId", requestId);

		return query.getResultList();
	}
	
	/*
	 * Function to fetch regex based on the regex type param passed from
	 * setup_regex_master
	 */
	public String getRegexValue(String regexType) {
		String regexValue = "";
		try {
			Query q = em.createNamedQuery(QuestionAnswer.GET_REGEX_VALUE_BY_REGEX_TYPE);
			q.setParameter("type", regexType);
			regexValue = (String) q.getSingleResult();
		} catch (Exception ex) {
			System.err.println(ex.getMessage());
			//ex.printStackTrace();
		}
		
		return regexValue;
	}

}
