package com.maybank.carisma.dao.commonQuestionnaire;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class QuestionnaireSaveDao {

	private static final Logger LOGGER = LogManager.getLogger(QuestionnaireSaveDao.class);

	private static final String COMMA = ",";

	@PersistenceContext
	private EntityManager em;

	public void insertQuestionInfo(String table,String questionnaireName,String primaryidentifier,long questionId,long answerId,String textAnswer,String createdBy) {

		String query = "INSERT INTO "+table+" (V_PRIMARY_IDENTIFIER,V_QUESTIONNAIRE_NAME,N_QUESTION_MASTER_ID,N_AVL_OPTIONS_TO_QUESTIONS_ID,V_ANSWER,D_CREATED_DTM,V_CREATED_BY,V_UPDATED_BY,D_UPDATED_DTM) VALUES(?,?,?,?,?,to_date(to_char(sysdate,'dd/mon/yyyy hh24:mi:ss'), 'dd/mm/yyyy hh24:mi:ss'),?,?,to_date(to_char(sysdate,'dd/mon/yyyy hh24:mi:ss'), 'dd/mm/yyyy hh24:mi:ss'))";
		em.createNativeQuery(query)
		.setParameter(1,primaryidentifier)
		.setParameter(2,questionnaireName)
		.setParameter(3,questionId)
		.setParameter(4,answerId)
		.setParameter(5,textAnswer)
		.setParameter(6,createdBy)
		.setParameter(7, createdBy)
		.executeUpdate();
	}

	public void updateQuestionnaireInfo(String table,String questionnaireName,String primaryIdentifer,long questionid,long answerId,String textAnswer, String updatedBy) {

		String query = "UPDATE "+table+" SET N_AVL_OPTIONS_TO_QUESTIONS_ID =:answerId , V_ANSWER =:textAnswer, D_UPDATED_DTM = to_date(to_char(sysdate,'dd/mon/yyyy hh24:mi:ss'), 'dd/mm/yyyy hh24:mi:ss'), V_UPDATED_BY=:updatedBy WHERE N_QUESTION_MASTER_ID =:questionid and V_QUESTIONNAIRE_NAME=:id and V_PRIMARY_IDENTIFIER=:primaryIdentifer ";
		em.createNativeQuery(query)
		.setParameter("questionid", questionid)
		.setParameter("id", questionnaireName)
		.setParameter("primaryIdentifer", primaryIdentifer)
		.setParameter("answerId", answerId)
		.setParameter("textAnswer", textAnswer)
		.setParameter("updatedBy", updatedBy)
		.executeUpdate();
	}

	public BigDecimal updateQuestionNumber(String table,String ucif,String questionnaireName, long id2) {

		String query = "SELECT count(*) FROM "+table+" WHERE V_PRIMARY_IDENTIFIER =:ucif and V_QUESTIONNAIRE_NAME =:id1 and N_QUESTION_MASTER_ID =:id2 ";
		Query  q = em.createNativeQuery(query);
		q.setParameter("ucif", ucif);
		q.setParameter("id1", questionnaireName);
		q.setParameter("id2", id2);
		BigDecimal number = (BigDecimal) q.getSingleResult();
		return number;
	}


	public List<Object[]> getQuestionnaireProperties() {
		String query="select q.vQuestionnaireName, q.responseTableName, q.responseStyle, q.separateTableFlag, qs.fMulpitpleSections, qs.responseStyle, qs.responseTable, qs.nQuestionnaireSectionsId from Questionnaire q INNER JOIN q.questionnaireSections qs";
		Query q = em.createQuery(query);

		return q.getResultList();
	}


	public List<Object[]> getTableNamesForAllQuesId() {
		String query= "select qm.nQuestionMasterId,qm.responseColumn from QuestionMaster qm where qm.responseColumn IS NOT NULL";
		Query q = em.createQuery(query);

		return q.getResultList();
	}


	public void insertColumnQuestionnaire(List<String> columnNames, List<Object> columnValues, String tableName, String primaryId, String questionName, String createdBy) {
		Date date = new Date();
		columnNames.add("V_PRIMARY_IDENTIFIER");
		columnValues.add(primaryId);
		columnNames.add("V_QUESTIONNAIRE_NAME");
		columnValues.add(questionName);
		columnNames.add("V_CREATED_BY");
		columnValues.add(createdBy);
		columnNames.add("V_UPDATED_BY");
		columnValues.add(createdBy);
		columnNames.add("D_CREATED_DATE");
		columnValues.add(date);
		columnNames.add("D_UPDATED_DATE");
		columnValues.add(date);
		String columnNameString = String.join(COMMA, columnNames);
		List<String> questionList = new ArrayList<String>();
		for(int i=0;i<columnNames.size();i++) {
			questionList.add("?");
		}
		String questionString = String.join(COMMA, questionList);

		String query= "INSERT INTO "+tableName+" ("+columnNameString+",N_SEQUENCE_ID) VALUES ("+questionString+",SEQ_"+tableName+".NEXTVAL)";
		Query  q = em.createNativeQuery(query);
		int j=1;
		for(Object obj:columnValues) {
			q.setParameter(j, obj);
			j++;
		}
		q.executeUpdate();
	}


	public void updateColumnQuestionnaire(List<String> columnNames, List<Object> columnValues, String tableName, String primaryId, String questionName, String updatedBy, Long seqId) {
		Date date = new Date();
		columnNames.add("V_UPDATED_BY");
		columnValues.add(updatedBy);
		columnNames.add("D_UPDATED_DATE");
		columnValues.add(date);
		int i=1;
		List<String> concatList=new ArrayList<>();
		for(String name:columnNames) {
			String nameConcat= name+"=:"+i;
			concatList.add(nameConcat);
			i++;
		}
		String concatString=String.join(COMMA, concatList);
		String query="UPDATE "+tableName+" SET "+concatString+" WHERE V_PRIMARY_IDENTIFIER =:ucif and V_QUESTIONNAIRE_NAME =:questionName and N_SEQUENCE_ID =:seqId";
		Query q = em.createNativeQuery(query);
		int j=1;
		for(Object val:columnValues) {
			q.setParameter(j, val);
			j++;
		}
		q.setParameter("ucif", primaryId);
		q.setParameter("questionName", questionName);
		q.setParameter("seqId", seqId);
		q.executeUpdate();
	}

	public BigDecimal getCount(String table,String ucif,String questionnaireName, Long seqId) {

		String query = "SELECT count(*) FROM "+table+" WHERE V_PRIMARY_IDENTIFIER =:ucif and V_QUESTIONNAIRE_NAME =:id1 and N_SEQUENCE_ID =:seqId";
		Query  q = em.createNativeQuery(query);
		q.setParameter("ucif", ucif);
		q.setParameter("id1", questionnaireName);
		q.setParameter("seqId", seqId);
		BigDecimal number = (BigDecimal) q.getSingleResult();
		return number;
	}

}
