/**
 * 
 */
package com.maybank.carisma.questionnaire.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="question_remark_map")
@NamedQuery(name = QuestionRemarkMap.GET_ALL_QUESTION_REMARK_MAP, query = "SELECT q FROM QuestionRemarkMap q")
public class QuestionRemarkMap {
	
	public static final String GET_ALL_QUESTION_REMARK_MAP="GET_ALL_QUESTION_REMARK_MAP";

	@Id
	@Column(name = "n_map_id")
	private Long mapId;

	@Column(name = "n_question_master_id")
	private Long questionMasterId;

	@Column(name = "n_remark_id")
	private Long remarkId;

	public Long getMapId() {
		return mapId;
	}

	public void setMapId(Long mapId) {
		this.mapId = mapId;
	}

	public Long getQuestionMasterId() {
		return questionMasterId;
	}

	public void setQuestionMasterId(Long questionMasterId) {
		this.questionMasterId = questionMasterId;
	}

	public Long getRemarkId() {
		return remarkId;
	}

	public void setRemarkId(Long remarkId) {
		this.remarkId = remarkId;
	}
	
}
