/**
 * 
 */
package com.maybank.carisma.questionnaire.vo;

/**
 * @author 00132020
 *
 */
public class ComponentMetadataDTO {
	private Long componentMetadataId;
	private Long questionMasterId;
private String propType;
private String propVal;

/**
 * @return the componentMetadataId
 */
public Long getComponentMetadataId() {
	return componentMetadataId;
}
/**
 * @param componentMetadataId the componentMetadataId to set
 */
public void setComponentMetadataId(Long componentMetadataId) {
	this.componentMetadataId = componentMetadataId;
}
/**
 * @return the questionMasterId
 */
public Long getQuestionMasterId() {
	return questionMasterId;
}
/**
 * @param questionMasterId the questionMasterId to set
 */
public void setQuestionMasterId(Long questionMasterId) {
	this.questionMasterId = questionMasterId;
}
/**
 * @return the propType
 */
public String getPropType() {
	return propType;
}
/**
 * @param propType the propType to set
 */
public void setPropType(String propType) {
	this.propType = propType;
}
/**
 * @return the propVal
 */
public String getPropVal() {
	return propVal;
}
/**
 * @param propVal the propVal to set
 */
public void setPropVal(String propVal) {
	this.propVal = propVal;
}

}
