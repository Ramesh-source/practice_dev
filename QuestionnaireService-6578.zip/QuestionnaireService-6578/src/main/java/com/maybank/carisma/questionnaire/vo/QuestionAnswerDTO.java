package com.maybank.carisma.questionnaire.vo;

import java.io.Serializable;

import com.maybank.carisma.questionnaire.constant.QuestionnaireConstant;

public class QuestionAnswerDTO implements Serializable {

	private static final long serialVersionUID = 79006041048452271L;

	private long requestId;

	private long questionnaireId;

	private String moduleName;

	private String questionId;

	private String questionText;

	private long sectionOrder;

	private OptionTypes optionTypes;

	private String answerId;

	private String answerText;

	private String answerDesc;
	
	private String commentDesc;
	
	public String getCommentDesc() {
		return commentDesc;
	}

	public void setCommentDesc(String commentDesc) {
		this.commentDesc = commentDesc;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public long getQuestionnaireId() {
		return questionnaireId;
	}

	public void setQuestionnaireId(long questionnaireId) {
		this.questionnaireId = questionnaireId;
	}

	public String getModuleName() {
		if(moduleName == null)
			return QuestionnaireConstant.MODULE_CRRS1;
		
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getAnswerId() {
		return answerId;
	}

	public void setAnswerId(String answerId) {
		this.answerId = answerId;
	}

	public String getAnswerDesc() {
		return answerDesc;
	}

	public void setAnswerDesc(String answerDesc) {
		this.answerDesc = answerDesc;
	}

	public long getSectionOrder() {
		return sectionOrder;
	}

	public void setSectionOrder(long sectionOrder) {
		this.sectionOrder = sectionOrder;
	}

	public OptionTypes getOptionTypes() {
		return optionTypes;
	}

	public void setOptionTypes(OptionTypes optionTypes) {
		this.optionTypes = optionTypes;
	}

	public String getQuestionText() {
		return questionText;
	}

	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}

	public String getAnswerText() {
		return answerText;
	}

	public void setAnswerText(String answerText) {
		this.answerText = answerText;
	}

	@Override
	public String toString() {
		return "QuestionAnswerDTO [questionId=" + questionId + ", questionText=" + questionText + ", sectionOrder="
				+ sectionOrder + ", optionTypes=" + optionTypes + ", answerId=" + answerId + ", answerText="
				+ answerText + ", answerDesc=" + answerDesc + "]";
	}

}
