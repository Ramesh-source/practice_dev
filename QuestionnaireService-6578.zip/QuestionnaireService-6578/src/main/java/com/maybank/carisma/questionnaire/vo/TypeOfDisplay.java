package com.maybank.carisma.questionnaire.vo;

/**
 * The Enum TypeOfDisplay.
 * 
 *  @author Sangit Banik
 */
public enum TypeOfDisplay {

	/** The hide show. */
	HIDE_SHOW,
	
	/** The enable disable. */
	ENABLE_DISABLE
}
