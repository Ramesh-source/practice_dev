package com.maybank.carisma.questionnaire.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the AVL_OPTIONS_TO_QUESTIONS database table.
 * 
 */
@Entity
@Table(name = "AVL_OPTIONS_TO_QUESTIONS")
@NamedQueries({
		@NamedQuery(name="AvlOptionsToQuestion.findAll", query="SELECT a FROM AvlOptionsToQuestion a"),
		@NamedQuery(name = AvlOptionsToQuestion.GET_OPTIONS_FOR_QUESTION_ID, query = "SELECT o FROM AvlOptionsToQuestion o WHERE o.questionMaster.nQuestionMasterId = :questionId ORDER BY o.nOptionOrder, o.nAvlOptionsToQuestionsId ") })
public class AvlOptionsToQuestion implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -656444798070601818L;

	public static final String GET_OPTIONS_FOR_QUESTION_ID = "GET_OPTIONS_FOR_QUESTION_ID";

	/** The n avl options to questions id. */
	@Id
	@SequenceGenerator(name = "avlOptions", sequenceName = "SEQ_AVL_OPTIONS_TO_QUESTION_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "avlOptions")
	@Column(name = "N_AVL_OPTIONS_TO_QUESTIONS_ID")
	private long nAvlOptionsToQuestionsId;

	/** The is leaf. */
	@Column(name = "F_IS_LEAF")
	private String fIsLeaf;

	/** The v option. */
	@Column(name = "V_OPTION")
	private String vOption;

	/** The question master. */
	// bi-directional many-to-one association to QuestionMaster
	@ManyToOne
	@JoinColumn(name = "N_QUESTION_MASTER_ID")
	private QuestionMaster questionMaster;

	/** The question options navigations. */
	// bi-directional many-to-one association to QuestionOptionsNavigation
	@OneToMany(mappedBy = "avlOptionsToQuestion")
	private Set<QuestionOptionsNavigation> questionOptionsNavigations;
	
	@Column(name = "n_option_order")
	private Integer nOptionOrder;
	
	/**
	 * @return the nOptionOrder
	 */
	public Integer getnOptionOrder() {
		return nOptionOrder;
	}

	/**
	 * @param nOptionOrder the nOptionOrder to set
	 */
	public void setnOptionOrder(Integer nOptionOrder) {
		this.nOptionOrder = nOptionOrder;
	}

	/**
	 * Gets the n avl options to questions id.
	 *
	 * @return the n avl options to questions id
	 */
	public long getNAvlOptionsToQuestionsId() {
		return this.nAvlOptionsToQuestionsId;
	}

	/**
	 * Sets the n avl options to questions id.
	 *
	 * @param nAvlOptionsToQuestionsId the new n avl options to questions id
	 */
	public void setNAvlOptionsToQuestionsId(long nAvlOptionsToQuestionsId) {
		this.nAvlOptionsToQuestionsId = nAvlOptionsToQuestionsId;
	}

	/**
	 * Gets the f is leaf.
	 *
	 * @return the f is leaf
	 */
	public String getFIsLeaf() {
		return this.fIsLeaf;
	}

	/**
	 * Sets the f is leaf.
	 *
	 * @param fIsLeaf the new f is leaf
	 */
	public void setFIsLeaf(String fIsLeaf) {
		this.fIsLeaf = fIsLeaf;
	}

	/**
	 * Gets the v option.
	 *
	 * @return the v option
	 */
	public String getVOption() {
		return this.vOption;
	}

	/**
	 * Sets the v option.
	 *
	 * @param vOption the new v option
	 */
	public void setVOption(String vOption) {
		this.vOption = vOption;
	}

	/**
	 * Gets the question master.
	 *
	 * @return the question master
	 */
	public QuestionMaster getQuestionMaster() {
		return this.questionMaster;
	}

	/**
	 * Sets the question master.
	 *
	 * @param questionMaster the new question master
	 */
	public void setQuestionMaster(QuestionMaster questionMaster) {
		this.questionMaster = questionMaster;
	}

	/**
	 * Gets the question options navigations.
	 *
	 * @return the question options navigations
	 */
	public Set<QuestionOptionsNavigation> getQuestionOptionsNavigations() {
		return this.questionOptionsNavigations;
	}

	/**
	 * Sets the question options navigations.
	 *
	 * @param questionOptionsNavigations the new question options navigations
	 */
	public void setQuestionOptionsNavigations(Set<QuestionOptionsNavigation> questionOptionsNavigations) {
		this.questionOptionsNavigations = questionOptionsNavigations;
	}

	/**
	 * Adds the question options navigation.
	 *
	 * @param questionOptionsNavigation the question options navigation
	 * @return the question options navigation
	 */
	public QuestionOptionsNavigation addQuestionOptionsNavigation(QuestionOptionsNavigation questionOptionsNavigation) {
		getQuestionOptionsNavigations().add(questionOptionsNavigation);
		questionOptionsNavigation.setAvlOptionsToQuestion(this);

		return questionOptionsNavigation;
	}

	/**
	 * Removes the question options navigation.
	 *
	 * @param questionOptionsNavigation the question options navigation
	 * @return the question options navigation
	 */
	public QuestionOptionsNavigation removeQuestionOptionsNavigation(
			QuestionOptionsNavigation questionOptionsNavigation) {
		getQuestionOptionsNavigations().remove(questionOptionsNavigation);
		questionOptionsNavigation.setAvlOptionsToQuestion(null);

		return questionOptionsNavigation;
	}

	@Override
	public String toString() {
		return "AvlOptionsToQuestion [nAvlOptionsToQuestionsId=" + nAvlOptionsToQuestionsId + ", fIsLeaf=" + fIsLeaf
				+ ", vOption=" + vOption + ", questionMasterId=" + questionMaster.getNQuestionMasterId() + ", questionOptionsNavigations="
				+ questionOptionsNavigations.size() + ", nOptionOrder=" + nOptionOrder + "]";
	}

	
}
