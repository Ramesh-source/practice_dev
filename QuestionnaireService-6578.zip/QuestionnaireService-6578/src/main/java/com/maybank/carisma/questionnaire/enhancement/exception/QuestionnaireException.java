package com.maybank.carisma.questionnaire.enhancement.exception;

public class QuestionnaireException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public QuestionnaireException(String errCode) {
		super(errCode);
	}

}
