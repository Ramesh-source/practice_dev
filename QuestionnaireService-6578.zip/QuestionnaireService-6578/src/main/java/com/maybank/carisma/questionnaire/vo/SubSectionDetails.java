package com.maybank.carisma.questionnaire.vo;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The Class SubSectionDetails.
 * 
 * @author Sangit Banik
 */
public class SubSectionDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The delete flag. */
	private boolean deleteFlag = false;

	/** The section name. */
	@JsonIgnore
	private String sectionName;

	/** The section id. */
	@JsonIgnore
	private long sectionId;

	/** The section order. */
	@JsonIgnore
	private long sectionOrder;

	/** The multiple responses. */
	@JsonIgnore
	private boolean multipleResponses;

	/** The component details. */
	private List<QuestionDTO> componentDetails;

	/**
	 * Checks if is delete flag.
	 *
	 * @return true, if is delete flag
	 */
	public boolean isDeleteFlag() {
		return deleteFlag;
	}

	/**
	 * Sets the delete flag.
	 *
	 * @param deleteFlag the new delete flag
	 */
	public void setDeleteFlag(boolean deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	/**
	 * Gets the component details.
	 *
	 * @return the component details
	 */
	public List<QuestionDTO> getComponentDetails() {
		return componentDetails;
	}

	/**
	 * Sets the component details.
	 *
	 * @param componentDetails the new component details
	 */
	public void setComponentDetails(List<QuestionDTO> componentDetails) {
		this.componentDetails = componentDetails;
	}

	/**
	 * Gets the section name.
	 *
	 * @return the section name
	 */
	public String getSectionName() {
		return sectionName;
	}

	/**
	 * Sets the section name.
	 *
	 * @param sectionName the new section name
	 */
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	/**
	 * Gets the section id.
	 *
	 * @return the section id
	 */
	public long getSectionId() {
		return sectionId;
	}

	/**
	 * Sets the section id.
	 *
	 * @param sectionId the new section id
	 */
	public void setSectionId(long sectionId) {
		this.sectionId = sectionId;
	}

	/**
	 * Gets the section order.
	 *
	 * @return the section order
	 */
	public long getSectionOrder() {
		return sectionOrder;
	}

	/**
	 * Sets the section order.
	 *
	 * @param sectionOrder the new section order
	 */
	public void setSectionOrder(long sectionOrder) {
		this.sectionOrder = sectionOrder;
	}

	/**
	 * Checks if is multiple responses.
	 *
	 * @return true, if is multiple responses
	 */
	public boolean isMultipleResponses() {
		return multipleResponses;
	}

	/**
	 * Sets the multiple responses.
	 *
	 * @param multipleResponses the new multiple responses
	 */
	public void setMultipleResponses(boolean multipleResponses) {
		this.multipleResponses = multipleResponses;
	}
}
