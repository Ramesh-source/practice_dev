package com.maybank.carisma.questionnaire.vo;

import java.util.List;

import com.maybank.carisma.vo.common.BaseRequestObject;

/**
 * The Class QuestionnaireSaveRequest.
 * 
 *  @author Sangit Banik
 */
public class QuestionnaireSaveRequest extends BaseRequestObject {

	/** The questionnaire name. */
	private String questionnaireName;
	
	/** The primary identifier. */
	private String primaryIdentifier;
	
	/** The question info. */
	private List<QuestionSaveInfo> questionInfo;
	
	/** The created by. */
	private String createdBy;
	
	/** The updated by. */
	private String updatedBy;

	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Gets the updated by.
	 *
	 * @return the updated by
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * Sets the updated by.
	 *
	 * @param updatedBy the new updated by
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * Gets the questionnaire name.
	 *
	 * @return the questionnaire name
	 */
	public String getQuestionnaireName() {
		return questionnaireName;
	}

	/**
	 * Sets the questionnaire name.
	 *
	 * @param questionnaireName the new questionnaire name
	 */
	public void setQuestionnaireName(String questionnaireName) {
		this.questionnaireName = questionnaireName;
	}

	/**
	 * Gets the primary identifier.
	 *
	 * @return the primary identifier
	 */
	public String getPrimaryIdentifier() {
		return primaryIdentifier;
	}

	/**
	 * Sets the primary identifier.
	 *
	 * @param primaryIdentifier the new primary identifier
	 */
	public void setPrimaryIdentifier(String primaryIdentifier) {
		this.primaryIdentifier = primaryIdentifier;
	}

	/**
	 * Gets the question info.
	 *
	 * @return the question info
	 */
	public List<QuestionSaveInfo> getQuestionInfo() {
		return questionInfo;
	}

	/**
	 * Sets the question info.
	 *
	 * @param questionInfo the new question info
	 */
	public void setQuestionInfo(List<QuestionSaveInfo> questionInfo) {
		this.questionInfo = questionInfo;
	}

}
