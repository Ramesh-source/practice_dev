package com.maybank.carisma.questionnaire.vo;

import java.util.List;

/**
 * The Class QuestionnaireProperties.
 * 
 *  @author Sangit Banik
 */
public class QuestionnaireProperties {
	
	/** The questionnaire name. */
	private String questionnaireName;
	
	/** The response table name. */
	private String responseTableName;
	
	/** The response style. */
	private String responseStyle;
	
	/** The separate section table. */
	private boolean separateSectionTable;
	
	/** The section properties. */
	private List<SectionProperties> sectionProperties;
	
	/**
	 * Gets the questionnaire name.
	 *
	 * @return the questionnaire name
	 */
	public String getQuestionnaireName() {
		return questionnaireName;
	}

	/**
	 * Sets the questionnaire name.
	 *
	 * @param questionnaireName the new questionnaire name
	 */
	public void setQuestionnaireName(String questionnaireName) {
		this.questionnaireName = questionnaireName;
	}

	/**
	 * Gets the response table name.
	 *
	 * @return the response table name
	 */
	public String getResponseTableName() {
		return responseTableName;
	}

	/**
	 * Sets the response table name.
	 *
	 * @param responseTableName the new response table name
	 */
	public void setResponseTableName(String responseTableName) {
		this.responseTableName = responseTableName;
	}

	/**
	 * Gets the response style.
	 *
	 * @return the response style
	 */
	public String getResponseStyle() {
		return responseStyle;
	}

	/**
	 * Sets the response style.
	 *
	 * @param responseStyle the new response style
	 */
	public void setResponseStyle(String responseStyle) {
		this.responseStyle = responseStyle;
	}

	/**
	 * Checks if is separate section table.
	 *
	 * @return true, if is separate section table
	 */
	public boolean isSeparateSectionTable() {
		return separateSectionTable;
	}

	/**
	 * Sets the separate section table.
	 *
	 * @param separateSectionTable the new separate section table
	 */
	public void setSeparateSectionTable(boolean separateSectionTable) {
		this.separateSectionTable = separateSectionTable;
	}

	/**
	 * Gets the section properties.
	 *
	 * @return the section properties
	 */
	public List<SectionProperties> getSectionProperties() {
		return sectionProperties;
	}

	/**
	 * Sets the section properties.
	 *
	 * @param sectionProperties the new section properties
	 */
	public void setSectionProperties(List<SectionProperties> sectionProperties) {
		this.sectionProperties = sectionProperties;
	}

}
