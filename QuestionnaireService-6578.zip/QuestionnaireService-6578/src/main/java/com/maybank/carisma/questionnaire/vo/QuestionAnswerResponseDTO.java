package com.maybank.carisma.questionnaire.vo;

import java.io.Serializable;
import java.util.List;

import com.maybank.carisma.vo.common.BaseResponseObject;

public class QuestionAnswerResponseDTO extends BaseResponseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long requestId;

	private long questionnaireId;

	private String questionnaireName;

	private String moduleName;
	
	private List<QuestionAnswerDTO> questionAnswerDTOList;
	
	/**
	 * @return the requestId
	 */
	public long getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the questionnaireId
	 */
	public long getQuestionnaireId() {
		return questionnaireId;
	}

	/**
	 * @param questionnaireId the questionnaireId to set
	 */
	public void setQuestionnaireId(long questionnaireId) {
		this.questionnaireId = questionnaireId;
	}

	/**
	 * @return the questionnaireName
	 */
	public String getQuestionnaireName() {
		return questionnaireName;
	}

	/**
	 * @param questionnaireName the questionnaireName to set
	 */
	public void setQuestionnaireName(String questionnaireName) {
		this.questionnaireName = questionnaireName;
	}

	/**
	 * @return the moduleName
	 */
	public String getModuleName() {
		return moduleName;
	}

	/**
	 * @param moduleName the moduleName to set
	 */
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	

	public List<QuestionAnswerDTO> getQuestionAnswerDTOList() {
		return questionAnswerDTOList;
	}

	public void setQuestionAnswerDTOList(List<QuestionAnswerDTO> questionAnswerDTOList) {
		this.questionAnswerDTOList = questionAnswerDTOList;
	}

	@Override
	public String toString() {
		return "QuestionAnswerResponseDTO [requestId=" + requestId + ", questionnaireId=" + questionnaireId
				+ ", moduleName=" + moduleName + ", questionAnswerDTOList=" + questionAnswerDTOList + "]";
	}

}
