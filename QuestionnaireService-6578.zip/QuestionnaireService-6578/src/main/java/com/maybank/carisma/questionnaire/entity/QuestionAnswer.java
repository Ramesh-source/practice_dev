package com.maybank.carisma.questionnaire.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.maybank.carisma.questionnaire.bean.QuestionAnswerBean;
import com.maybank.carisma.questionnaire.bean.QuestionAnswerKeyBean;
import com.maybank.carisma.questionnaire.vo.OptionTypes;

@Entity
@Table(name = "QUESTION_ANSWER")
@NamedQueries({
		@NamedQuery(name = QuestionAnswer.GET_ANSWER, query = "Select a from QuestionAnswer a where a.questionAnswerKey.requestId = :requestId AND a.questionAnswerKey.questionnaireId = :questionnaireId AND a.questionAnswerKey.questionId = :questionId"),
		@NamedQuery(name = QuestionAnswer.DELETE_SECTION_QUESTION_ANSWER, query = "delete from QuestionAnswer a where a.questionAnswerKey.requestId = :requestId"),
		@NamedQuery(name = QuestionAnswer.GET_COUNT_ON_SECTION_QUESTION_ANSWER, query = "select count(*) from QuestionAnswer a where a.questionAnswerKey.requestId = :requestId"),
		@NamedQuery(name = QuestionAnswer.GET_QUESTIONNAIRE_ID_FOR_REQUEST_ID, query = "select distinct a.questionAnswerKey.questionnaireId from QuestionAnswer a where a.questionAnswerKey.requestId = :requestId"),
		@NamedQuery(name = QuestionAnswer.UPDATE_ANSWER_WITH_NULL, query = "UPDATE QuestionAnswer sqa SET sqa.answerId = null, sqa.answerDesc = null where sqa.questionAnswerKey.requestId = :requestId AND sqa.questionAnswerKey.questionId >= :questionId"),
		@NamedQuery(name = QuestionAnswer.GET_QUESTION_ANSWER_BY_REQUEST_ID, query = "Select a from QuestionAnswer a where a.questionAnswerKey.requestId = :requestId"),
		@NamedQuery(name = QuestionAnswer.GET_REGEX_VALUE_BY_REGEX_TYPE, query = "Select a from RegexMaster a where a.regexType = :regexType")
})

public class QuestionAnswer implements Serializable {

	private static final long serialVersionUID = -1160500650072388401L;

	public static final String GET_ANSWER = "GET_ANSWER";

	public static final String DELETE_SECTION_QUESTION_ANSWER = "DELETE_SECTION_QUESTION_ANSWER";

	public static final String GET_COUNT_ON_SECTION_QUESTION_ANSWER = "GET_COUNT_ON_SECTION_QUESTION_ANSWER";

	public static final String GET_QUESTIONNAIRE_ID_FOR_REQUEST_ID = "GET_QUESTIONNAIRE_ID_FOR_REQUEST_ID";

	public static final String UPDATE_ANSWER_WITH_NULL = "UPDATE_ANSWER_WITH_NULL";

	public static final String GET_QUESTION_ANSWER_BY_REQUEST_ID = "GET_QUESTION_ANSWER_BY_REQUEST_ID";

	public static final String GET_REGEX_VALUE_BY_REGEX_TYPE = "GET_REGEX_VALUE_BY_REGEX_TYPE";

	@EmbeddedId
	QuestionAnswerKey questionAnswerKey;

	@Column(name = "V_OPTION_SELECTION_TYPE")
	@Enumerated(EnumType.STRING)
	private OptionTypes optionTypes;

	@Column(name = "V_ANSWER")
	private String answerId;

	@Column(name = "V_ANSWER_DESC")
	private String answerDesc;

	@Column(name = "N_SECTION_ORDER")
	private long sectionOrder;
	
	@Column(name = "v_remark")
	private String remark;

	public QuestionAnswerKey getQuestionAnswerKey() {
		return questionAnswerKey;
	}

	public QuestionAnswer setQuestionAnswerKey(QuestionAnswerKey questionAnswerKey) {
		this.questionAnswerKey = questionAnswerKey;
		return this;
	}

	public OptionTypes getOptionTypes() {
		return optionTypes;
	}

	public QuestionAnswer setOptionTypes(OptionTypes optionTypes) {
		this.optionTypes = optionTypes;
		return this;
	}

	public String getAnswerId() {
		return answerId;
	}

	public QuestionAnswer setAnswerId(String answerId) {
		this.answerId = answerId;
		return this;
	}

	public String getAnswerDesc() {
		return answerDesc;
	}

	public QuestionAnswer setAnswerDesc(String answerDesc) {
		this.answerDesc = answerDesc;
		return this;
	}

	public long getSectionOrder() {
		return sectionOrder;
	}

	public QuestionAnswer setSectionOrder(long sectionOrder) {
		this.sectionOrder = sectionOrder;
		return this;
	}

	public String getRemark() {
		return remark;
	}

	public QuestionAnswer setRemark(String remark) {
		this.remark = remark;
		return this;
	}
	
	public QuestionAnswerBean toBean() {
		return new QuestionAnswerBean()
				.setQuestionAnswerKey(questionAnswerKey != null ? questionAnswerKey.toBean() : new QuestionAnswerKeyBean())
				.setOptionTypes(optionTypes)
				.setAnswerId(answerId)
				.setAnswerDesc(answerDesc)
				.setSectionOrder(sectionOrder)
				.setRemark(remark);
	}

	@Override
	public String toString() {
		return "QuestionAnswer [questionAnswerKey=" + questionAnswerKey + ", optionTypes=" + optionTypes + ", answerId="
				+ answerId + ", answerDesc=" + answerDesc + ", sectionOrder=" + sectionOrder + ", remark=" + remark
				+ "]";
	}
	
}
