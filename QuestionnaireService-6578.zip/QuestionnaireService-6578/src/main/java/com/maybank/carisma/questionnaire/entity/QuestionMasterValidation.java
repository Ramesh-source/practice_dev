package com.maybank.carisma.questionnaire.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.maybank.carisma.questionnaire.vo.QuestionMasterValidationBean;

@Entity
@Table(name = "QUESTION_MASTER_VALIDATION")
@NamedQuery(name = QuestionMasterValidation.GET_ALL_QUESTION_MASTER_VALIDATIONS, query = "SELECT q FROM QuestionMasterValidation q")
public class QuestionMasterValidation implements Serializable{

	private static final long serialVersionUID = 6999462423896608650L;
	
	public static final String GET_ALL_QUESTION_MASTER_VALIDATIONS = "GET_ALL_QUESTION_MASTER_VALIDATIONS";

	@Id
	@SequenceGenerator(name = "questionMasterValidation", sequenceName = "SEQ_QUESTION_VALIDATION_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "questionMasterValidation")
	@Column(name="N_QUESTION_VALIDATION_ID")
	private long questionValidationId;
	
	@Column(name="N_QUESTION_MASTER_ID")
	private long questionMasterId;
	
	@Column(name="V_VALIDATION_TYPE")
	private String validationType; // MANDATORY / REGEX
	
	@Column(name="V_VALIDATION_VALUE")
	private String validationValue;
	
	@Column(name="V_ERROR_CODE")
	private String errorCode;

	@Column (name="V_REMARK_MANDATORY_VALIDATION")
	private String remarkMandatoryValidation;

	public long getQuestionValidationId() {
		return questionValidationId;
	}

	public void setQuestionValidationId(long questionValidationId) {
		this.questionValidationId = questionValidationId;
	}

	public long getQuestionMasterId() {
		return questionMasterId;
	}

	public void setQuestionMasterId(long questionMasterId) {
		this.questionMasterId = questionMasterId;
	}

	public String getValidationType() {
		return validationType;
	}

	public void setValidationType(String validationType) {
		this.validationType = validationType;
	}

	public String getValidationValue() {
		return validationValue;
	}

	public void setValidationValue(String validationValue) {
		this.validationValue = validationValue;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	public String getRemarkMandatoryValidation() {
		return remarkMandatoryValidation;
	}

	public void setRemarkMandatoryValidation(String remarkMandatoryValidation) {
		this.remarkMandatoryValidation = remarkMandatoryValidation;
	}

	public QuestionMasterValidationBean toBean() {
		return new QuestionMasterValidationBean()
				.setQuestionValidationId(this.questionValidationId)
				.setQuestionMasterId(this.questionMasterId)
				.setValidationType(this.validationType)
				.setValidationValue(this.validationValue)
				.setErrorCode(this.errorCode)
				.setRemarkMandatoryValidation(this.remarkMandatoryValidation);
	}
	
}
